// Task Definition
export interface Task {
  id: string;
  title: string;
  date: string; // ISO string format YYYY-MM-DD
  startTime?: string; // 24-hour format HH:MM
  endTime?: string; // 24-hour format HH:MM
  category?: string;
  notes?: string;
  completed: boolean;
  duration?: number; // in minutes
}

// Subject for Revision Timetable
export interface RevisionSubject {
  id: string;
  name: string;
  topics: string[];
  duration: string; // e.g. "2h daily"
  status: 'on-track' | 'needs-focus' | 'behind';
  color: 'primary' | 'secondary' | 'accent' | 'warning' | 'error' | 'success';
}

// App Settings
export interface AppSettings {
  userName: string;
  pomodoroDuration: string; // in minutes
  breakDuration: string; // in minutes
  darkMode: boolean;
  notifications: boolean;
}

// User Stats
export interface UserStats {
  totalTasksCompleted: number;
  totalStudyHours: number;
  currentStreak: number;
  longestStreak: number;
}

// Export Data Format
export interface AppData {
  tasks: Task[];
  revisionSubjects: RevisionSubject[];
  settings: AppSettings;
  stats: UserStats;
}
