/// <reference lib="webworker" />

// This service worker can be customized
// See https://developers.google.com/web/tools/workbox/modules
// for the list of available Workbox modules

declare const self: ServiceWorkerGlobalScope;

const CACHE_NAME = "dayflow-cache-v1";
const OFFLINE_URL = "/";

// URLs to cache immediately on service worker installation
const STATIC_ASSETS = [
  "/", 
  "/src/main.tsx", 
  "/src/index.css"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  
  // Force the waiting service worker to become the active service worker
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  // Clean up old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
          return null;
        }).filter(Boolean)
      );
    })
  );
  
  // Immediately claim clients so updates are applied immediately
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return;
  }
  
  // Handle navigation requests differently
  if (event.request.mode === "navigate") {
    event.respondWith(
      (async () => {
        try {
          // Try the network first
          const networkResponse = await fetch(event.request);
          
          // Save the response in cache for later offline use
          const cache = await caches.open(CACHE_NAME);
          cache.put(event.request, networkResponse.clone());
          
          return networkResponse;
        } catch (error) {
          // Network failed, try the cache
          const cachedResponse = await caches.match(event.request);
          
          if (cachedResponse) {
            return cachedResponse;
          }
          
          // If no cached response, serve the offline page
          const offlineResponse = await caches.match(OFFLINE_URL);
          return offlineResponse || Response.error();
        }
      })()
    );
  } else if (
    event.request.method === "GET" && 
    event.request.destination !== "document"
  ) {
    // For non-HTML requests, use a stale-while-revalidate strategy
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((cachedResponse) => {
          const fetchPromise = fetch(event.request)
            .then((networkResponse) => {
              // Save a copy of the response in cache
              cache.put(event.request, networkResponse.clone());
              return networkResponse;
            })
            .catch(() => {
              // When network fails, do nothing
              // We'll return the cached response if we have one
            });
          
          // Return the cached response if we have one, otherwise wait for the network response
          return cachedResponse || fetchPromise;
        });
      })
    );
  }
  
  // All other requests, just try the network
});

// Handle push notifications
self.addEventListener("push", (event) => {
  const data = event.data?.json() ?? { title: "New notification", body: "You have a new notification" };
  
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzYzNjZGMSI+PHBhdGggZD0iTTEyLjc1IDEyLjc1YS43NS43NSAwIDExLTEuNSAwIC43NS43NSAwIDAxMS41IDB6TTcuNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNOC4yNSAxNy4yNWEuNzUuNzUgMCAxMS0xLjUgMCAuNzUuNzUgMCAwMTEuNSAwek05Ljc1IDE1Ljc1YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41ek0xMC41IDE3LjI1YS43NS43NSAwIDExLTEuNSAwIC43NS43NSAwIDAxMS41IDB6TTEyIDE1Ljc1YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41ek0xMi43NSAxNy4yNWEuNzUuNzUgMCAxMS0xLjUgMCAuNzUuNzUgMCAwMTEuNSAwek0xNC4yNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNMTUgMTcuMjVhLjc1Ljc1IDAgMTEtMS41IDAgLjc1Ljc1IDAgMDExLjUgMHpNMTYuNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNMTUgMTIuNzVhLjc1Ljc1IDAgMTEtMS41IDAgLjc1Ljc1IDAgMDExLjUgMHpNMTYuNSAxMy41YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41eiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02Ljc1IDIuMjVBLjc1Ljc1IDAgMDE3LjUgM3YxLjVoOVYzQS43NS43NSAwIDAxMTggM3YxLjVoLjc1YTMgMyAwIDAxMyAzdjExLjI1YTMgMyAwIDAxLTMgM0g1LjI1YTMgMyAwIDAxLTMtM1Y3LjVhMyAzIDAgMDEzLTNINlYzYS43NS43NSAwIDAxLjc1LS43NXptMTMuNSA5YTEuNSAxLjUgMCAwMC0xLjUtMS41SDUuMjVhMS41IDEuNSAwIDAwLTEuNSAxLjV2Ny41YTEuNSAxLjUgMCAwMDEuNSAxLjVoMTMuNWExLjUgMS41IDAgMDAxLjUtMS41di03LjV6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIC8+PC9zdmc+",
      badge: "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzYzNjZGMSI+PHBhdGggZD0iTTEyLjc1IDEyLjc1YS43NS43NSAwIDExLTEuNSAwIC43NS43NSAwIDAxMS41IDB6TTcuNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNOC4yNSAxNy4yNWEuNzUuNzUgMCAxMS0xLjUgMCAuNzUuNzUgMCAwMTEuNSAwek05Ljc1IDE1Ljc1YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41ek0xMC41IDE3LjI1YS43NS43NSAwIDExLTEuNSAwIC43NS43NSAwIDAxMS41IDB6TTEyIDE1Ljc1YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41ek0xMi43NSAxNy4yNWEuNzUuNzUgMCAxMS0xLjUgMCAuNzUuNzUgMCAwMTEuNSAwek0xNC4yNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNMTUgMTcuMjVhLjc1Ljc1IDAgMTEtMS41IDAgLjc1Ljc1IDAgMDExLjUgMHpNMTYuNSAxNS43NWEuNzUuNzUgMCAxMDAtMS41Ljc1Ljc1IDAgMDAwIDEuNXpNMTUgMTIuNzVhLjc1Ljc1IDAgMTEtMS41IDAgLjc1Ljc1IDAgMDExLjUgMHpNMTYuNSAxMy41YS43NS43NSAwIDEwMC0xLjUuNzUuNzUgMCAwMDAgMS41eiIgLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02Ljc1IDIuMjVBLjc1Ljc1IDAgMDE3LjUgM3YxLjVoOVYzQS43NS43NSAwIDAxMTggM3YxLjVoLjc1YTMgMyAwIDAxMyAzdjExLjI1YTMgMyAwIDAxLTMgM0g1LjI1YTMgMyAwIDAxLTMtM1Y3LjVhMyAzIDAgMDEzLTNINlYzYS43NS43NSAwIDAxLjc1LS43NXptMTMuNSA5YTEuNSAxLjUgMCAwMC0xLjUtMS41SDUuMjVhMS41IDEuNSAwIDAwLTEuNSAxLjV2Ny41YTEuNSAxLjUgMCAwMDEuNSAxLjVoMTMuNWExLjUgMS41IDAgMDAxLjUtMS41di03LjV6IiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIC8+PC9zdmc+",
      vibrate: [200, 100, 200]
    })
  );
});

// Handle notification clicks
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clientList) => {
      // If we have an open window, focus it
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && "focus" in client) {
          return client.focus();
        }
      }
      
      // Otherwise open a new window
      if (self.clients.openWindow) {
        return self.clients.openWindow("/");
      }
    })
  );
});

// Periodic sync for background updates
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "update-data") {
    event.waitUntil(
      // Update cached resources in background
      caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(STATIC_ASSETS);
      })
    );
  }
});

// Expose the version for debugging purposes
self.addEventListener("message", (event) => {
  if (event.data === "version") {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});
