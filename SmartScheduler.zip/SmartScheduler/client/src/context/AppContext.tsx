import React, { createContext, useContext, useState, useEffect } from "react";
import useLocalStorage from "@/hooks/useLocalStorage";
import { Task, RevisionSubject, AppSettings, UserStats } from "@/types";
import { generateMockSchedule } from "@/lib/mockAI";

// Define the shape of our context
interface AppContextProps {
  // Tasks
  tasks: Task[];
  addTask: (task: Task) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  clearAllTasks: () => void;
  
  // Revision Subjects
  revisionSubjects: RevisionSubject[];
  addRevisionSubject: (subject: RevisionSubject) => void;
  updateRevisionSubject: (subject: RevisionSubject) => void;
  deleteRevisionSubject: (id: string) => void;
  
  // User Settings
  userName: string;
  setUserName: (name: string) => void;
  pomodoroDuration: string;
  setPomodoroDuration: (duration: string) => void;
  breakDuration: string;
  setBreakDuration: (duration: string) => void;
  
  // UI State
  showNewTaskModal: boolean;
  setShowNewTaskModal: (show: boolean) => void;
  
  // Stats
  stats: UserStats;
  updateStats: (stats: Partial<UserStats>) => void;
  
  // AI Features
  generateAISchedule: () => void;
  
  // Data Management
  exportData: () => void;
  importData: (data: string) => void;
}

// Create the context with default values
const AppContext = createContext<AppContextProps>({
  tasks: [],
  addTask: () => {},
  updateTask: () => {},
  deleteTask: () => {},
  clearAllTasks: () => {},
  
  revisionSubjects: [],
  addRevisionSubject: () => {},
  updateRevisionSubject: () => {},
  deleteRevisionSubject: () => {},
  
  userName: "",
  setUserName: () => {},
  pomodoroDuration: "25",
  setPomodoroDuration: () => {},
  breakDuration: "5",
  setBreakDuration: () => {},
  
  showNewTaskModal: false,
  setShowNewTaskModal: () => {},
  
  stats: {
    totalTasksCompleted: 0,
    totalStudyHours: 0,
    currentStreak: 0,
    longestStreak: 0
  },
  updateStats: () => {},
  
  generateAISchedule: () => {},
  
  exportData: () => {},
  importData: () => {}
});

// Provider component for making context available to children
export const AppProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  // Tasks state
  const [tasks, setTasks] = useLocalStorage<Task[]>("tasks", []);
  
  // Revision subjects state
  const [revisionSubjects, setRevisionSubjects] = useLocalStorage<RevisionSubject[]>(
    "revisionSubjects",
    [
      {
        id: "math-1",
        name: "Mathematics",
        topics: ["Calculus", "Algebra"],
        duration: "2h daily",
        status: "on-track",
        color: "primary"
      },
      {
        id: "physics-1",
        name: "Physics",
        topics: ["Mechanics", "Waves"],
        duration: "1.5h daily",
        status: "needs-focus",
        color: "secondary"
      }
    ]
  );
  
  // User settings
  const [settings, setSettings] = useLocalStorage<AppSettings>("settings", {
    userName: "Alex",
    pomodoroDuration: "25",
    breakDuration: "5",
    darkMode: false,
    notifications: true
  });
  
  // UI state
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  
  // User statistics
  const [stats, setStats] = useLocalStorage<UserStats>("stats", {
    totalTasksCompleted: 0,
    totalStudyHours: 0,
    currentStreak: 0,
    longestStreak: 0
  });
  
  // Update stats when tasks change
  useEffect(() => {
    const completedTasks = tasks.filter(task => task.completed).length;
    
    // Calculate total study hours
    const totalMinutes = tasks.reduce((total, task) => {
      if (task.completed && task.duration) {
        return total + task.duration;
      }
      return total;
    }, 0);
    
    const totalHours = Math.round(totalMinutes / 60 * 10) / 10; // Round to 1 decimal place
    
    setStats(prev => ({
      ...prev,
      totalTasksCompleted: completedTasks,
      totalStudyHours: totalHours
    }));
  }, [tasks]);
  
  // Add a new task
  const addTask = (task: Task) => {
    setTasks(prev => [...prev, task]);
  };
  
  // Update an existing task
  const updateTask = (updatedTask: Task) => {
    setTasks(prev =>
      prev.map(task => (task.id === updatedTask.id ? updatedTask : task))
    );
  };
  
  // Delete a task
  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };
  
  // Clear all tasks
  const clearAllTasks = () => {
    setTasks([]);
  };
  
  // Add a new revision subject
  const addRevisionSubject = (subject: RevisionSubject) => {
    setRevisionSubjects(prev => [...prev, subject]);
  };
  
  // Update an existing revision subject
  const updateRevisionSubject = (updatedSubject: RevisionSubject) => {
    setRevisionSubjects(prev =>
      prev.map(subject => (subject.id === updatedSubject.id ? updatedSubject : subject))
    );
  };
  
  // Delete a revision subject
  const deleteRevisionSubject = (id: string) => {
    setRevisionSubjects(prev => prev.filter(subject => subject.id !== id));
  };
  
  // Update user settings
  const setUserName = (name: string) => {
    setSettings(prev => ({ ...prev, userName: name }));
  };
  
  const setPomodoroDuration = (duration: string) => {
    setSettings(prev => ({ ...prev, pomodoroDuration: duration }));
  };
  
  const setBreakDuration = (duration: string) => {
    setSettings(prev => ({ ...prev, breakDuration: duration }));
  };
  
  // Update user stats
  const updateStats = (newStats: Partial<UserStats>) => {
    setStats(prev => ({ ...prev, ...newStats }));
  };
  
  // Generate AI Schedule
  const generateAISchedule = () => {
    const subjectNames = revisionSubjects.map(subject => subject.name);
    const aiSchedule = generateMockSchedule(subjectNames);
    
    // Merge new AI schedule with existing tasks (don't overwrite existing)
    const existingTaskDates = tasks.map(task => `${task.date}-${task.startTime}`);
    
    const filteredAISchedule = aiSchedule.filter(
      task => !existingTaskDates.includes(`${task.date}-${task.startTime}`)
    );
    
    setTasks(prev => [...prev, ...filteredAISchedule]);
  };
  
  // Data export/import
  const exportData = () => {
    const data = {
      tasks,
      revisionSubjects,
      settings,
      stats
    };
    
    const jsonData = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement("a");
    a.href = url;
    a.download = `dayflow-backup-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const importData = (jsonData: string) => {
    try {
      const data = JSON.parse(jsonData);
      
      if (data.tasks) {
        setTasks(data.tasks);
      }
      
      if (data.revisionSubjects) {
        setRevisionSubjects(data.revisionSubjects);
      }
      
      if (data.settings) {
        setSettings(data.settings);
      }
      
      if (data.stats) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error("Failed to import data:", error);
      throw new Error("Invalid data format");
    }
  };
  
  // Provide the value to children
  return (
    <AppContext.Provider
      value={{
        tasks,
        addTask,
        updateTask,
        deleteTask,
        clearAllTasks,
        
        revisionSubjects,
        addRevisionSubject,
        updateRevisionSubject,
        deleteRevisionSubject,
        
        userName: settings.userName,
        setUserName,
        pomodoroDuration: settings.pomodoroDuration,
        setPomodoroDuration,
        breakDuration: settings.breakDuration,
        setBreakDuration,
        
        showNewTaskModal,
        setShowNewTaskModal,
        
        stats,
        updateStats,
        
        generateAISchedule,
        
        exportData,
        importData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

// Custom hook for using the app context
export const useAppContext = () => useContext(AppContext);
