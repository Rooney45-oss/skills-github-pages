import { useEffect } from "react";
import useLocalStorage from "./useLocalStorage";

interface UseDarkModeOutput {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  enableDarkMode: () => void;
  disableDarkMode: () => void;
}

/**
 * Custom hook for managing dark mode
 */
export function useDarkMode(): UseDarkModeOutput {
  const [isDarkMode, setIsDarkMode] = useLocalStorage<boolean>("darkMode", false);
  
  // Update the document's class list whenever the dark mode state changes
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);
  
  // Check system preference on mount
  useEffect(() => {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    // If dark mode hasn't been set yet (first visit), use system preference
    const darkModeSet = localStorage.getItem("darkMode") !== null;
    if (!darkModeSet && prefersDark) {
      setIsDarkMode(true);
    }
  }, []);
  
  const toggleDarkMode = () => {
    setIsDarkMode(prevMode => !prevMode);
  };
  
  const enableDarkMode = () => {
    setIsDarkMode(true);
  };
  
  const disableDarkMode = () => {
    setIsDarkMode(false);
  };
  
  return {
    isDarkMode,
    toggleDarkMode,
    enableDarkMode,
    disableDarkMode
  };
}
