import { useRef, useState, useEffect } from "react";

interface SwipeHandlers {
  onSwipedLeft?: () => void;
  onSwipedRight?: () => void;
  onSwipedUp?: () => void;
  onSwipedDown?: () => void;
  onSwiping?: (deltaX: number, deltaY: number) => void;
}

interface SwipeableHandlers {
  onTouchStart: (e: React.TouchEvent) => void;
  onTouchMove: (e: React.TouchEvent) => void;
  onTouchEnd: (e: React.TouchEvent) => void;
  onMouseDown: (e: React.MouseEvent) => void;
  onMouseMove: (e: React.MouseEvent) => void;
  onMouseUp: (e: React.MouseEvent) => void;
  onMouseLeave: (e: React.MouseEvent) => void;
}

export function useSwipeable(handlers: SwipeHandlers): SwipeableHandlers {
  const [isSwiping, setIsSwiping] = useState(false);
  const startXRef = useRef<number>(0);
  const startYRef = useRef<number>(0);
  const currentXRef = useRef<number>(0);
  const currentYRef = useRef<number>(0);
  
  // Minimum distance to consider it a swipe
  const threshold = 50;
  
  // Handle touch start or mouse down
  const handleStart = (clientX: number, clientY: number) => {
    setIsSwiping(true);
    startXRef.current = clientX;
    startYRef.current = clientY;
    currentXRef.current = clientX;
    currentYRef.current = clientY;
  };
  
  // Handle touch move or mouse move
  const handleMove = (clientX: number, clientY: number) => {
    if (!isSwiping) return;
    
    currentXRef.current = clientX;
    currentYRef.current = clientY;
    
    if (handlers.onSwiping) {
      const deltaX = startXRef.current - currentXRef.current;
      const deltaY = startYRef.current - currentYRef.current;
      handlers.onSwiping(deltaX, deltaY);
    }
  };
  
  // Handle touch end or mouse up
  const handleEnd = () => {
    if (!isSwiping) return;
    
    const deltaX = startXRef.current - currentXRef.current;
    const deltaY = startYRef.current - currentYRef.current;
    
    // Determine swipe direction if it exceeds threshold
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);
    
    if (absX > absY && absX > threshold) {
      // Horizontal swipe
      if (deltaX > 0) {
        handlers.onSwipedLeft?.();
      } else {
        handlers.onSwipedRight?.();
      }
    } else if (absY > absX && absY > threshold) {
      // Vertical swipe
      if (deltaY > 0) {
        handlers.onSwipedUp?.();
      } else {
        handlers.onSwipedDown?.();
      }
    }
    
    setIsSwiping(false);
  };
  
  // Touch event handlers
  const onTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    handleStart(touch.clientX, touch.clientY);
  };
  
  const onTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    handleMove(touch.clientX, touch.clientY);
  };
  
  const onTouchEnd = () => {
    handleEnd();
  };
  
  // Mouse event handlers
  const onMouseDown = (e: React.MouseEvent) => {
    handleStart(e.clientX, e.clientY);
  };
  
  const onMouseMove = (e: React.MouseEvent) => {
    handleMove(e.clientX, e.clientY);
  };
  
  const onMouseUp = () => {
    handleEnd();
  };
  
  const onMouseLeave = () => {
    handleEnd();
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      setIsSwiping(false);
    };
  }, []);
  
  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
    onMouseDown,
    onMouseMove,
    onMouseUp,
    onMouseLeave
  };
}
