import { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import { useLocation } from "wouter";
import { useAppContext } from "@/context/AppContext";

interface WeekDay {
  day: string;
  date: number;
  current: boolean;
}

interface Subject {
  id: string;
  name: string;
  topics: string[];
  duration: string;
  status: 'on-track' | 'needs-focus' | 'behind';
  color: 'primary' | 'secondary' | 'accent' | 'warning' | 'error' | 'success';
}

const RevisionTimetable = () => {
  const [, setLocation] = useLocation();
  const { revisionSubjects } = useAppContext();
  const [weekDays, setWeekDays] = useState<WeekDay[]>([]);
  const [currentWeek, setCurrentWeek] = useState(0);
  const timetableRef = useRef<HTMLDivElement>(null);
  
  // Generate weekdays data for the calendar
  useEffect(() => {
    generateWeekDays();
  }, [currentWeek]);
  
  // Animation effects
  useEffect(() => {
    if (timetableRef.current) {
      gsap.from(timetableRef.current.querySelectorAll('.day-circle'), {
        scale: 0.8,
        opacity: 0,
        stagger: 0.05,
        duration: 0.4,
        ease: "back.out(1.7)"
      });
      
      gsap.from(timetableRef.current.querySelectorAll('.subject-card'), {
        y: 20,
        opacity: 0,
        stagger: 0.1,
        duration: 0.5,
        delay: 0.3,
        ease: "power3.out"
      });
    }
  }, [weekDays, revisionSubjects]);
  
  const generateWeekDays = () => {
    const today = new Date();
    const currentDay = today.getDay(); // 0 (Sunday) - 6 (Saturday)
    const firstDayOfWeek = new Date(today);
    
    // Adjust to show current week with offset based on currentWeek state
    firstDayOfWeek.setDate(today.getDate() - currentDay + (currentWeek * 7));
    
    const days: WeekDay[] = [];
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    
    // Generate 5 weekdays (Mon-Fri)
    for (let i = 0; i < 5; i++) {
      const date = new Date(firstDayOfWeek);
      date.setDate(firstDayOfWeek.getDate() + i + 1); // +1 because firstDayOfWeek is Sunday
      
      days.push({
        day: dayNames[i],
        date: date.getDate(),
        current: date.toDateString() === today.toDateString()
      });
    }
    
    setWeekDays(days);
  };
  
  const navigatePrevWeek = () => {
    setCurrentWeek(prev => prev - 1);
  };
  
  const navigateNextWeek = () => {
    setCurrentWeek(prev => prev + 1);
  };
  
  // Get text color class based on status
  const getStatusTextColor = (status: Subject['status']) => {
    switch (status) {
      case 'on-track':
        return 'text-success';
      case 'needs-focus':
        return 'text-warning';
      case 'behind':
        return 'text-error';
      default:
        return 'text-success';
    }
  };
  
  // Get background color for category tag
  const getTagColorClass = (color: Subject['color']) => {
    switch (color) {
      case 'primary':
        return 'bg-primary bg-opacity-10 text-primary';
      case 'secondary':
        return 'bg-secondary bg-opacity-10 text-secondary';
      case 'accent':
        return 'bg-accent bg-opacity-10 text-accent';
      case 'warning':
        return 'bg-warning bg-opacity-10 text-warning';
      case 'error':
        return 'bg-error bg-opacity-10 text-error';
      case 'success':
        return 'bg-success bg-opacity-10 text-success';
      default:
        return 'bg-primary bg-opacity-10 text-primary';
    }
  };
  
  // Get background color for category bar
  const getBarColorClass = (color: Subject['color']) => {
    switch (color) {
      case 'primary':
        return 'bg-primary';
      case 'secondary':
        return 'bg-secondary';
      case 'accent':
        return 'bg-accent';
      case 'warning':
        return 'bg-warning';
      case 'error':
        return 'bg-error';
      case 'success':
        return 'bg-success';
      default:
        return 'bg-primary';
    }
  };

  return (
    <div ref={timetableRef}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-heading font-semibold text-lg">Revision Timetable</h3>
        <button 
          className="text-primary font-medium flex items-center text-sm"
          onClick={() => setLocation("/schedule")}
        >
          <span>Edit Plan</span>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 ml-1">
            <path fillRule="evenodd" d="M7.21 14.77a.75.75 0 0 1 .02-1.06L11.168 10 7.23 6.29a.75.75 0 1 1 1.04-1.08l4.5 4.25a.75.75 0 0 1 0 1.08l-4.5 4.25a.75.75 0 0 1-1.06-.02Z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
      
      <div className="bg-card rounded-xl shadow-md p-4">
        <div className="flex justify-between mb-4">
          <button 
            className="text-gray-500 dark:text-gray-400"
            onClick={navigatePrevWeek}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
            </svg>
          </button>
          <h4 className="font-medium">{currentWeek === 0 ? 'This Week' : currentWeek < 0 ? 'Past Week' : 'Next Week'}</h4>
          <button 
            className="text-gray-500 dark:text-gray-400"
            onClick={navigateNextWeek}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
            </svg>
          </button>
        </div>
        
        <div className="grid grid-cols-5 gap-2">
          {weekDays.map((day, index) => (
            <div key={index} className="text-center">
              <div className="mb-1 text-sm text-gray-500 dark:text-gray-400">{day.day}</div>
              <div 
                className={`day-circle w-10 h-10 mx-auto rounded-full flex items-center justify-center ${
                  day.current 
                    ? 'bg-primary text-white' 
                    : 'bg-primary bg-opacity-10 text-primary'
                }`}
              >
                <span>{day.date}</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-5 space-y-3">
          {revisionSubjects.length > 0 ? (
            revisionSubjects.map((subject, index) => (
              <div key={subject.id} className="subject-card bg-background rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className={`w-2 h-10 ${getBarColorClass(subject.color)} rounded-full mr-3`}></div>
                    <div>
                      <h5 className="font-medium">{subject.name}</h5>
                      <div className="flex space-x-2 mt-1">
                        {subject.topics.map((topic, topicIndex) => (
                          <span 
                            key={topicIndex} 
                            className={`text-xs px-2 py-0.5 ${getTagColorClass(subject.color)} rounded`}
                          >
                            {topic}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-500 dark:text-gray-400">{subject.duration}</div>
                    <div className={`text-xs ${getStatusTextColor(subject.status)}`}>{subject.status === 'on-track' ? 'On track' : subject.status === 'needs-focus' ? 'Needs focus' : 'Behind'}</div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-gray-600">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
              </svg>
              <p className="text-gray-500 dark:text-gray-400">No revision subjects added yet</p>
              <button 
                onClick={() => setLocation("/settings")}
                className="mt-4 px-4 py-2 bg-primary text-white rounded-md text-sm font-medium"
              >
                Add Subjects
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RevisionTimetable;
