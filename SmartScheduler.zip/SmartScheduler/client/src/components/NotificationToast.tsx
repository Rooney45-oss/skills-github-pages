import { useEffect, useRef } from "react";
import { gsap } from "gsap";

interface NotificationToastProps {
  show: boolean;
  message: string;
  type?: 'success' | 'error' | 'warning';
  onClose: () => void;
}

const NotificationToast = ({ show, message, type = 'success', onClose }: NotificationToastProps) => {
  const toastRef = useRef<HTMLDivElement>(null);
  
  // Handle animation and auto-close
  useEffect(() => {
    if (show && toastRef.current) {
      // Animate in
      gsap.fromTo(toastRef.current, 
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.3, ease: "power2.out" }
      );
      
      // Auto dismiss after 3 seconds
      const timeout = setTimeout(() => {
        handleClose();
      }, 3000);
      
      return () => clearTimeout(timeout);
    }
  }, [show]);
  
  const handleClose = () => {
    if (toastRef.current) {
      // Animate out
      gsap.to(toastRef.current, {
        y: -20, 
        opacity: 0, 
        duration: 0.3,
        ease: "power2.in",
        onComplete: onClose
      });
    } else {
      onClose();
    }
  };
  
  if (!show) return null;
  
  // Get the appropriate icon and background color based on type
  const getTypeStyles = () => {
    switch (type) {
      case 'success':
        return {
          icon: (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 0 1 .208 1.04l-9 13.5a.75.75 0 0 1-1.154.114l-6-6a.75.75 0 0 1 1.06-1.06l5.353 5.353 8.493-12.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
            </svg>
          ),
          bgColor: 'bg-success'
        };
      case 'error':
        return {
          icon: (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clipRule="evenodd" />
            </svg>
          ),
          bgColor: 'bg-error'
        };
      case 'warning':
        return {
          icon: (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clipRule="evenodd" />
            </svg>
          ),
          bgColor: 'bg-warning'
        };
      default:
        return {
          icon: (
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 0 1 .208 1.04l-9 13.5a.75.75 0 0 1-1.154.114l-6-6a.75.75 0 0 1 1.06-1.06l5.353 5.353 8.493-12.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
            </svg>
          ),
          bgColor: 'bg-success'
        };
    }
  };
  
  const { icon, bgColor } = getTypeStyles();
  
  return (
    <div 
      ref={toastRef}
      className="fixed top-5 left-1/2 transform -translate-x-1/2 z-50 bg-card rounded-lg shadow-lg p-4 flex items-center max-w-xs w-full"
    >
      <div className={`w-8 h-8 rounded-full ${bgColor} flex items-center justify-center text-white mr-3`}>
        {icon}
      </div>
      <div className="flex-1">
        <h4 className="font-medium text-sm">
          {type === 'success' ? 'Success!' : type === 'error' ? 'Error!' : 'Warning!'}
        </h4>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          {message}
        </p>
      </div>
      <button 
        className="ml-2 text-gray-400 hover:text-gray-500"
        onClick={handleClose}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default NotificationToast;
