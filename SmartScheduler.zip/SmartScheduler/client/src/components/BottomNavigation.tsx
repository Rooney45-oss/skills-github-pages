import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { gsap } from "gsap";
import { useAppContext } from "@/context/AppContext";

const BottomNavigation = () => {
  const [location, setLocation] = useLocation();
  const { setShowNewTaskModal } = useAppContext();
  
  useEffect(() => {
    // Animate the navigation on mount
    gsap.from(".bottom-nav", { 
      y: 50, 
      opacity: 0, 
      duration: 0.5, 
      ease: "power3.out",
      delay: 0.3
    });
  }, []);

  const navigateTo = (path: string) => {
    setLocation(path);
  };

  const handleAddTask = () => {
    setShowNewTaskModal(true);
  };

  return (
    <nav className="bottom-nav fixed bottom-0 left-0 right-0 bg-card border-t border-gray-200 dark:border-gray-800 py-2 px-4 flex justify-around items-center z-50">
      <button 
        className={`flex flex-col items-center justify-center p-2 ${location === '/' ? 'text-primary' : 'text-gray-500 dark:text-gray-400'}`}
        onClick={() => navigateTo('/')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path d="M11.47 3.841a.75.75 0 0 1 1.06 0l8.69 8.69a.75.75 0 1 0 1.06-1.061l-8.689-8.69a2.25 2.25 0 0 0-3.182 0l-8.69 8.69a.75.75 0 1 0 1.061 1.06l8.69-8.689Z" />
          <path d="m12 5.432 8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75V21a.75.75 0 0 1-.75.75H5.625a1.875 1.875 0 0 1-1.875-1.875v-6.198c.03-.028.061-.057.091-.086L12 5.432Z" />
        </svg>
        <span className="text-xs mt-1">Home</span>
      </button>
      
      <button 
        className={`flex flex-col items-center justify-center p-2 ${location === '/schedule' ? 'text-primary' : 'text-gray-500 dark:text-gray-400'}`}
        onClick={() => navigateTo('/schedule')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path fillRule="evenodd" d="M6.75 2.25A.75.75 0 0 1 7.5 3v1.5h9V3A.75.75 0 0 1 18 3v1.5h.75a3 3 0 0 1 3 3v11.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V7.5a3 3 0 0 1 3-3H6V3a.75.75 0 0 1 .75-.75Zm13.5 9a1.5 1.5 0 0 0-1.5-1.5H5.25a1.5 1.5 0 0 0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5v-7.5Z" clipRule="evenodd" />
        </svg>
        <span className="text-xs mt-1">Schedule</span>
      </button>
      
      <button 
        className="relative -mt-6 bg-primary rounded-full w-14 h-14 flex items-center justify-center text-white shadow-lg transition-transform duration-200 hover:scale-110 active:scale-95"
        onClick={handleAddTask}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path fillRule="evenodd" d="M12 3.75a.75.75 0 0 1 .75.75v6.75h6.75a.75.75 0 0 1 0 1.5h-6.75v6.75a.75.75 0 0 1-1.5 0v-6.75H4.5a.75.75 0 0 1 0-1.5h6.75V4.5a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
        </svg>
      </button>
      
      <button 
        className={`flex flex-col items-center justify-center p-2 ${location === '/progress' ? 'text-primary' : 'text-gray-500 dark:text-gray-400'}`}
        onClick={() => navigateTo('/progress')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path d="M18.375 2.25c-1.035 0-1.875.84-1.875 1.875v15.75c0 1.035.84 1.875 1.875 1.875h.75c1.035 0 1.875-.84 1.875-1.875V4.125c0-1.036-.84-1.875-1.875-1.875h-.75ZM9.75 8.625c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-.75a1.875 1.875 0 0 1-1.875-1.875V8.625ZM3 13.125c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v6.75c0 1.035-.84 1.875-1.875 1.875h-.75A1.875 1.875 0 0 1 3 19.875v-6.75Z" />
        </svg>
        <span className="text-xs mt-1">Progress</span>
      </button>
      
      <button 
        className={`flex flex-col items-center justify-center p-2 ${location === '/settings' ? 'text-primary' : 'text-gray-500 dark:text-gray-400'}`}
        onClick={() => navigateTo('/settings')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
          <path fillRule="evenodd" d="M11.078 2.25c-.917 0-1.699.663-1.85 1.567L9.05 4.889c-.02.12-.115.26-.297.348a7.493 7.493 0 0 0-.986.57c-.166.115-.334.126-.45.083L6.3 5.508a1.875 1.875 0 0 0-2.282.819l-.922 1.597a1.875 1.875 0 0 0 .432 2.385l.84.692c.095.078.17.229.154.43a7.598 7.598 0 0 0 0 1.139c.015.2-.059.352-.153.43l-.841.692a1.875 1.875 0 0 0-.432 2.385l.922 1.597a1.875 1.875 0 0 0 2.282.818l1.019-.382c.115-.043.283-.031.45.082.312.214.641.405.985.57.182.088.277.228.297.35l.178 1.071c.151.904.933 1.567 1.85 1.567h1.844c.916 0 1.699-.663 1.85-1.567l.178-1.072c.02-.12.114-.26.297-.349.344-.165.673-.356.985-.57.167-.114.335-.125.45-.082l1.02.382a1.875 1.875 0 0 0 2.28-.819l.923-1.597a1.875 1.875 0 0 0-.432-2.385l-.84-.692c-.095-.078-.17-.229-.154-.43a7.614 7.614 0 0 0 0-1.139c-.016-.2.059-.352.153-.43l.84-.692c.708-.582.891-1.59.433-2.385l-.922-1.597a1.875 1.875 0 0 0-2.282-.818l-1.02.382c-.114.043-.282.031-.449-.083a7.49 7.49 0 0 0-.985-.57c-.183-.087-.277-.227-.297-.348l-.179-1.072a1.875 1.875 0 0 0-1.85-1.567h-1.843ZM12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" clipRule="evenodd" />
        </svg>
        <span className="text-xs mt-1">Settings</span>
      </button>
    </nav>
  );
};

export default BottomNavigation;
