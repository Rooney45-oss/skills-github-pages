import { useEffect, useRef } from "react";
import { gsap } from "gsap";

interface ProgressRingProps {
  percentage: number;
  size: number;
  strokeWidth: number;
  duration?: number;
}

const ProgressRing = ({ percentage, size, strokeWidth, duration = 1 }: ProgressRingProps) => {
  const circleRef = useRef<SVGCircleElement>(null);
  
  // Calculate circle properties
  const radius = (size / 2) - (strokeWidth / 2);
  const circumference = radius * 2 * Math.PI;
  const dashOffset = circumference - (percentage / 100) * circumference;
  
  useEffect(() => {
    if (circleRef.current) {
      // Reset to 0 and animate to current percentage
      gsap.set(circleRef.current, { strokeDashoffset: circumference });
      gsap.to(circleRef.current, {
        strokeDashoffset: dashOffset,
        duration: duration,
        ease: "power2.out"
      });
    }
  }, [percentage, circumference, dashOffset, duration]);

  return (
    <div className="relative w-24 h-24 flex items-center justify-center">
      <svg className="w-full h-full" viewBox={`0 0 ${size} ${size}`}>
        {/* Background circle */}
        <circle 
          cx={size / 2} 
          cy={size / 2} 
          r={radius} 
          fill="none" 
          stroke="hsl(var(--muted))" 
          strokeWidth={strokeWidth} 
        />
        
        {/* Progress circle */}
        <circle 
          ref={circleRef}
          className="progress-ring-circle" 
          cx={size / 2} 
          cy={size / 2} 
          r={radius} 
          fill="none" 
          stroke="hsl(var(--primary))" 
          strokeWidth={strokeWidth} 
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          style={{
            transformOrigin: "center",
            transform: "rotate(-90deg)"
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center flex-col">
        <span className="text-2xl font-bold">{percentage}%</span>
        <span className="text-xs text-gray-500 dark:text-gray-400">Completed</span>
      </div>
    </div>
  );
};

export default ProgressRing;
