import { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAppContext } from "@/context/AppContext";
import { Task } from "@/types";
import { formatDateForInput } from "@/lib/dates";

interface NewTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTaskAdded?: (task: Task) => void;
  initialDate?: Date;
}

const NewTaskModal = ({ isOpen, onClose, onTaskAdded, initialDate }: NewTaskModalProps) => {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(formatDateForInput(initialDate || new Date()));
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [category, setCategory] = useState("Study");
  const [notes, setNotes] = useState("");
  
  const modalRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  
  const { addTask } = useAppContext();

  // Reset form when modal opens with potentially new initialDate
  useEffect(() => {
    if (isOpen) {
      setDate(formatDateForInput(initialDate || new Date()));
    }
  }, [isOpen, initialDate]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
      
      // Animate the modal opening
      gsap.to(modalRef.current, {
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        duration: 0.3,
        ease: "power2.out"
      });
      
      gsap.to(contentRef.current, {
        y: 0,
        duration: 0.4,
        ease: "power2.out"
      });
    } else {
      document.body.style.overflow = "";
      
      // Reset animations when closed
      if (modalRef.current && contentRef.current) {
        gsap.set(modalRef.current, { backgroundColor: "rgba(0, 0, 0, 0)" });
        gsap.set(contentRef.current, { y: "100%" });
      }
    }
    
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !date) return;
    
    const newTask: Task = {
      id: Date.now().toString(),
      title,
      date,
      startTime,
      endTime,
      category,
      notes,
      completed: false,
      duration: startTime && endTime ? calculateDuration(startTime, endTime) : 60 // Default 60 minutes if no times provided
    };
    
    addTask(newTask);
    
    if (onTaskAdded) {
      onTaskAdded(newTask);
    }
    
    resetForm();
    onClose();
  };

  const calculateDuration = (start: string, end: string): number => {
    const [startHours, startMinutes] = start.split(':').map(Number);
    const [endHours, endMinutes] = end.split(':').map(Number);
    
    const startTotalMinutes = startHours * 60 + startMinutes;
    const endTotalMinutes = endHours * 60 + endMinutes;
    
    // If end time is before start time, assume it's the next day
    return endTotalMinutes >= startTotalMinutes 
      ? endTotalMinutes - startTotalMinutes 
      : endTotalMinutes + (24 * 60) - startTotalMinutes;
  };

  const resetForm = () => {
    setTitle("");
    setDate(formatDateForInput(new Date()));
    setStartTime("");
    setEndTime("");
    setCategory("Study");
    setNotes("");
  };

  const handleCancel = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
      ref={modalRef}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center"
      onClick={onClose}
    >
      <div 
        ref={contentRef}
        className="bg-card rounded-t-2xl w-full max-w-md p-5 transform translate-y-full"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-5">
          <h3 className="font-heading font-semibold text-xl">New Task</h3>
          <button 
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700"
            onClick={onClose}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="taskTitle" className="block text-sm font-medium mb-1">Task Title</label>
            <Input
              id="taskTitle"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter task title"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="taskDate" className="block text-sm font-medium mb-1">Date</label>
              <Input
                id="taskDate"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </div>
            
            <div>
              <label htmlFor="taskStartTime" className="block text-sm font-medium mb-1">Start Time</label>
              <Input
                id="taskStartTime"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="taskEndTime" className="block text-sm font-medium mb-1">End Time</label>
              <Input
                id="taskEndTime"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
            
            <div>
              <label htmlFor="taskCategory" className="block text-sm font-medium mb-1">Category</label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="taskCategory">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Study">Study</SelectItem>
                  <SelectItem value="Revision">Revision</SelectItem>
                  <SelectItem value="Assignment">Assignment</SelectItem>
                  <SelectItem value="Exam Prep">Exam Prep</SelectItem>
                  <SelectItem value="Break">Break</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label htmlFor="taskNotes" className="block text-sm font-medium mb-1">Notes</label>
            <Textarea
              id="taskNotes"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes (optional)"
            />
          </div>
          
          <div className="flex space-x-3 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1"
              onClick={handleCancel}
            >
              Cancel
            </Button>
            
            <Button 
              type="submit" 
              className="flex-1"
            >
              Add Task
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewTaskModal;
