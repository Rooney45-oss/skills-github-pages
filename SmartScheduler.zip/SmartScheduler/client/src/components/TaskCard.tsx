import { useState, useRef, useEffect } from "react";
import { gsap } from "gsap";
import { useSwipeable } from "@/hooks/useSwipeable";
import { useAppContext } from "@/context/AppContext";
import { Task } from "@/types";
import { formatTime } from "@/lib/dates";

interface TaskCardProps {
  task: Task;
  onComplete: () => void;
  onDelete: () => void;
}

const TaskCard = ({ task, onComplete, onDelete }: TaskCardProps) => {
  const [isSwiped, setIsSwiped] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { updateTask, deleteTask } = useAppContext();
  
  // Animation setup
  useEffect(() => {
    gsap.set(cardRef.current, { 
      opacity: 1,
      y: 0, 
      scale: 1
    });
  }, []);

  // Configure swipe handlers
  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => {
      setIsSwiped(true);
      gsap.to(contentRef.current, {
        x: -80,
        duration: 0.3,
        ease: "power2.out"
      });
    },
    onSwipedRight: () => {
      setIsSwiped(false);
      gsap.to(contentRef.current, {
        x: 0,
        duration: 0.3,
        ease: "power2.out"
      });
    }
  });

  // Reset swipe state when clicked anywhere else
  const handleOutsideClick = () => {
    if (isSwiped) {
      setIsSwiped(false);
      gsap.to(contentRef.current, {
        x: 0,
        duration: 0.3,
        ease: "power2.out"
      });
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleOutsideClick);
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [isSwiped]);

  const handleComplete = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    const clone = {...task, completed: true};
    updateTask(clone);
    
    // Animate task completion
    gsap.to(cardRef.current, {
      scale: 0.95,
      opacity: 0,
      y: -20,
      duration: 0.3,
      ease: "power2.in",
      onComplete: () => {
        onComplete();
      }
    });
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Animate task deletion
    gsap.to(cardRef.current, {
      x: "100%",
      opacity: 0,
      duration: 0.3,
      ease: "power2.in",
      onComplete: () => {
        deleteTask(task.id);
        onDelete();
      }
    });
  };

  // Determine task color based on category
  const getCategoryColor = () => {
    switch (task.category) {
      case 'Study':
        return 'bg-primary';
      case 'Revision':
        return 'bg-secondary';
      case 'Assignment':
        return 'bg-accent';
      case 'Exam Prep':
        return 'bg-warning';
      case 'Break':
        return 'bg-success';
      default:
        return 'bg-primary';
    }
  };

  // Determine task status
  const getTaskStatus = () => {
    if (task.completed) {
      return {
        label: 'Completed',
        className: 'bg-success bg-opacity-10 text-success'
      };
    }
    
    const now = new Date();
    const taskStartTime = new Date(task.date);
    const taskEndTime = new Date(task.date);
    
    if (task.startTime) {
      const [hours, minutes] = task.startTime.split(':').map(Number);
      taskStartTime.setHours(hours, minutes);
    }
    
    if (task.endTime) {
      const [hours, minutes] = task.endTime.split(':').map(Number);
      taskEndTime.setHours(hours, minutes);
    } else {
      // If no end time, assume 1 hour duration
      taskEndTime.setHours(taskStartTime.getHours() + 1);
    }
    
    if (now >= taskStartTime && now <= taskEndTime) {
      return {
        label: 'In Progress',
        className: 'bg-primary bg-opacity-10 text-primary'
      };
    }
    
    return {
      label: 'Upcoming',
      className: 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
    };
  };

  const taskStatus = getTaskStatus();
  const categoryColor = getCategoryColor();

  return (
    <div 
      ref={cardRef}
      className="swipe-container bg-card rounded-lg shadow-sm overflow-hidden"
      {...swipeHandlers}
      onClick={(e) => e.stopPropagation()}
    >
      <div 
        ref={contentRef}
        className="swipe-content task-card p-3 flex items-center transition-transform duration-300"
        style={{ transform: isSwiped ? 'translateX(-80px)' : 'translateX(0)' }}
      >
        <div className={`w-2 h-16 ${categoryColor} rounded-full mr-4`}></div>
        <div className="flex-1">
          <h4 className="font-medium">{task.title}</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {task.startTime ? formatTime(task.startTime) : ''} 
            {task.startTime && task.endTime ? ' - ' : ''} 
            {task.endTime ? formatTime(task.endTime) : ''}
          </p>
        </div>
        <div className="ml-2">
          <span className={`px-2 py-1 ${taskStatus.className} text-xs rounded-md`}>
            {taskStatus.label}
          </span>
        </div>
      </div>
      <div className="swipe-action flex absolute right-0 top-0 h-full">
        <button 
          className="bg-error text-white px-4 flex items-center justify-center"
          onClick={handleDelete}
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
            <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 0 1 3.878.512.75.75 0 1 1-.256 1.478l-.209-.035-1.005 13.07a3 3 0 0 1-2.991 2.77H8.084a3 3 0 0 1-2.991-2.77L4.087 6.66l-.209.035a.75.75 0 0 1-.256-1.478A48.567 48.567 0 0 1 7.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.951a52.662 52.662 0 0 1 3.369 0c1.603.051 2.815 1.387 2.815 2.951Zm-6.136-1.452a51.196 51.196 0 0 1 3.273 0C14.39 3.05 15 3.684 15 4.478v.113a49.488 49.488 0 0 0-6 0v-.113c0-.794.609-1.428 1.364-1.452Zm-.355 5.945a.75.75 0 1 0-1.5.058l.347 9a.75.75 0 1 0 1.499-.058l-.346-9Zm5.48.058a.75.75 0 1 0-1.498-.058l-.347 9a.75.75 0 0 0 1.5.058l.345-9Z" clipRule="evenodd" />
          </svg>
        </button>
        <button 
          className="bg-success text-white px-4 flex items-center justify-center"
          onClick={handleComplete}
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
            <path fillRule="evenodd" d="M19.916 4.626a.75.75 0 0 1 .208 1.04l-9 13.5a.75.75 0 0 1-1.154.114l-6-6a.75.75 0 0 1 1.06-1.06l5.353 5.353 8.493-12.74a.75.75 0 0 1 1.04-.207Z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default TaskCard;
