import { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Button } from "@/components/ui/button";
import { useAppContext } from "@/context/AppContext";
import { generateResponse, AIChatMessage } from "@/lib/mockAI";

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIAssistantModal = ({ isOpen, onClose }: AIAssistantModalProps) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      role: "ai",
      content: "Hi there! How can I help you with your planning today?"
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { userName, tasks, generateAISchedule } = useAppContext();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
      
      // Animate the modal opening
      gsap.to(modalRef.current, {
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        duration: 0.3,
        ease: "power2.out"
      });
      
      gsap.to(contentRef.current, {
        y: 0,
        duration: 0.4,
        ease: "power2.out"
      });
    } else {
      document.body.style.overflow = "";
      
      // Reset animations when closed
      if (modalRef.current && contentRef.current) {
        gsap.set(modalRef.current, { backgroundColor: "rgba(0, 0, 0, 0)" });
        gsap.set(contentRef.current, { y: "100%" });
      }
    }
    
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  // Scroll to bottom of messages when new messages are added
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;
    
    // Add user message
    const userMessage = {
      role: "user" as const,
      content: inputValue
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsGenerating(true);
    
    // Generate AI response
    setTimeout(async () => {
      const aiResponse = await generateResponse(userMessage.content, messages, {
        userName: userName || "User",
        taskCount: tasks.length,
        completedTaskCount: tasks.filter(t => t.completed).length
      });
      
      setMessages(prev => [...prev, { role: "ai", content: aiResponse }]);
      setIsGenerating(false);
    }, 1000); // Simulate AI thinking time
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleGenerateSchedule = () => {
    generateAISchedule();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
      ref={modalRef}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center"
      onClick={onClose}
    >
      <div 
        ref={contentRef}
        className="bg-card rounded-t-2xl w-full max-w-md p-5 transform translate-y-full"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-5">
          <h3 className="font-heading font-semibold text-xl">AI Assistant</h3>
          <button 
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-200 dark:hover:bg-gray-700"
            onClick={onClose}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="mb-5 h-96 overflow-y-auto pr-2">
          {messages.map((message, index) => (
            <div key={index} className={`flex items-start mb-4 ${message.role === 'user' ? 'justify-end' : ''}`}>
              {message.role === 'ai' && (
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                    <path d="M16.5 7.5h-9v9h9v-9Z" />
                    <path fillRule="evenodd" d="M8.25 2.25A.75.75 0 0 1 9 3v.75h2.25V3a.75.75 0 0 1 1.5 0v.75H15V3a.75.75 0 0 1 1.5 0v.75h.75a3 3 0 0 1 3 3v.75H21A.75.75 0 0 1 21 9h-.75v2.25H21a.75.75 0 0 1 0 1.5h-.75V15H21a.75.75 0 0 1 0 1.5h-.75v.75a3 3 0 0 1-3 3h-.75V21a.75.75 0 0 1-1.5 0v-.75h-2.25V21a.75.75 0 0 1-1.5 0v-.75H9V21a.75.75 0 0 1-1.5 0v-.75h-.75a3 3 0 0 1-3-3v-.75H3A.75.75 0 0 1 3 15h.75v-2.25H3a.75.75 0 0 1 0-1.5h.75V9H3a.75.75 0 0 1 0-1.5h.75v-.75a3 3 0 0 1 3-3h.75V3a.75.75 0 0 1 .75-.75ZM6 6.75A.75.75 0 0 1 6.75 6h10.5a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V6.75Z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
              
              <div 
                className={`${
                  message.role === 'ai' 
                    ? 'bg-gray-100 dark:bg-gray-800 rounded-lg rounded-tl-none' 
                    : 'bg-primary bg-opacity-10 rounded-lg rounded-tr-none'
                } p-3 max-w-[80%] ${index === messages.length - 1 && message.role === 'ai' ? 'animate-fade-in' : ''}`}
              >
                <p 
                  className={`text-sm ${message.role === 'user' ? 'text-primary' : ''}`}
                  dangerouslySetInnerHTML={{ __html: message.content.replace(/\n/g, '<br/>') }}
                />
              </div>
              
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-gray-300 dark:bg-gray-600 flex items-center justify-center ml-3">
                  <span className="text-xs font-semibold">{userName ? userName[0] : "U"}</span>
                </div>
              )}
            </div>
          ))}
          
          {isGenerating && (
            <div className="flex items-start mb-4">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                  <path d="M16.5 7.5h-9v9h9v-9Z" />
                  <path fillRule="evenodd" d="M8.25 2.25A.75.75 0 0 1 9 3v.75h2.25V3a.75.75 0 0 1 1.5 0v.75H15V3a.75.75 0 0 1 1.5 0v.75h.75a3 3 0 0 1 3 3v.75H21A.75.75 0 0 1 21 9h-.75v2.25H21a.75.75 0 0 1 0 1.5h-.75V15H21a.75.75 0 0 1 0 1.5h-.75v.75a3 3 0 0 1-3 3h-.75V21a.75.75 0 0 1-1.5 0v-.75h-2.25V21a.75.75 0 0 1-1.5 0v-.75H9V21a.75.75 0 0 1-1.5 0v-.75h-.75a3 3 0 0 1-3-3v-.75H3A.75.75 0 0 1 3 15h.75v-2.25H3a.75.75 0 0 1 0-1.5h.75V9H3a.75.75 0 0 1 0-1.5h.75v-.75a3 3 0 0 1 3-3h.75V3a.75.75 0 0 1 .75-.75ZM6 6.75A.75.75 0 0 1 6.75 6h10.5a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V6.75Z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="bg-gray-100 dark:bg-gray-800 rounded-lg rounded-tl-none p-4 max-w-[80%]">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></div>
                  <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></div>
                  <div className="w-2 h-2 bg-gray-400 dark:bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: "600ms" }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        {messages.some(m => m.content.includes("create a detailed timetable")) && (
          <div className="flex space-x-2 mb-4">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={onClose}
            >
              No, thanks
            </Button>
            <Button 
              className="flex-1" 
              onClick={handleGenerateSchedule}
            >
              Yes, please!
            </Button>
          </div>
        )}
        
        <div className="relative">
          <input 
            type="text" 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything..." 
            className="w-full bg-gray-100 dark:bg-gray-800 rounded-full py-3 pl-4 pr-12 focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            disabled={isGenerating}
          />
          <button 
            className={`absolute right-1 top-1 bg-primary text-white rounded-full w-10 h-10 flex items-center justify-center transition-opacity ${inputValue.trim() === '' || isGenerating ? 'opacity-50' : 'opacity-100'}`}
            onClick={handleSendMessage}
            disabled={inputValue.trim() === '' || isGenerating}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIAssistantModal;
