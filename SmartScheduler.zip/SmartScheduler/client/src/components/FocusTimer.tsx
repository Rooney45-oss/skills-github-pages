import { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import { useAppContext } from "@/context/AppContext";

type TimerState = 'idle' | 'running' | 'paused' | 'completed';

const FocusTimer = () => {
  const [timerState, setTimerState] = useState<TimerState>('idle');
  const [timeRemaining, setTimeRemaining] = useState(25 * 60); // 25 minutes in seconds
  const [isPomodoro, setIsPomodoro] = useState(true);
  const timerRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<number | null>(null);
  const { pomodoroDuration, breakDuration } = useAppContext();
  
  // Convert pomodoro/break duration from minutes to seconds
  const pomodoroSeconds = parseInt(pomodoroDuration) * 60;
  const breakSeconds = parseInt(breakDuration) * 60;
  
  // Reset timer when pomodoro/break settings change or timer type changes
  useEffect(() => {
    resetTimer();
  }, [pomodoroDuration, breakDuration, isPomodoro]);
  
  // Animation effects
  useEffect(() => {
    const timeline = gsap.timeline();
    
    if (timerRef.current) {
      timeline
        .from(timerRef.current.querySelector('.timer-text'), { 
          scale: 0.9, 
          opacity: 0, 
          duration: 0.5, 
          ease: "power3.out" 
        })
        .from(timerRef.current.querySelectorAll('.timer-button'), { 
          y: 20, 
          opacity: 0, 
          stagger: 0.1, 
          duration: 0.4, 
          ease: "back.out(1.7)" 
        }, "-=0.2");
    }
    
    return () => {
      timeline.kill();
    };
  }, []);
  
  // Timer functionality
  useEffect(() => {
    if (timerState === 'running') {
      intervalRef.current = window.setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(intervalRef.current as number);
            setTimerState('completed');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerState]);
  
  // Handle timer state transitions
  useEffect(() => {
    if (timerState === 'completed') {
      playNotificationSound();
      // Auto switch between pomodoro and break
      setIsPomodoro(prev => !prev);
      // Don't auto-start the next timer
      setTimerState('idle');
    }
  }, [timerState]);
  
  const startTimer = () => {
    setTimerState('running');
  };
  
  const pauseTimer = () => {
    setTimerState('paused');
  };
  
  const resetTimer = () => {
    setTimerState('idle');
    setTimeRemaining(isPomodoro ? pomodoroSeconds : breakSeconds);
  };
  
  const skipToNext = () => {
    setIsPomodoro(prev => !prev);
    setTimerState('idle');
  };
  
  const playNotificationSound = () => {
    try {
      const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-software-interface-alert-notification-256.mp3');
      audio.play();
    } catch (error) {
      console.error('Failed to play notification sound:', error);
    }
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div ref={timerRef} className="bg-card rounded-xl shadow-md p-4 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-primary opacity-5 rounded-full -mr-8 -mt-8"></div>
      <div className="absolute bottom-0 left-0 w-16 h-16 bg-secondary opacity-5 rounded-full -ml-6 -mb-6"></div>
      
      <h3 className="font-heading font-semibold text-lg mb-3">Focus Timer</h3>
      
      <div className="flex justify-center my-4">
        <div className="text-center">
          <div className="timer-text text-4xl font-bold font-heading text-primary">
            {formatTime(timeRemaining)}
          </div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            {isPomodoro ? 'Pomodoro Session' : 'Break Time'}
          </div>
        </div>
      </div>
      
      <div className="flex justify-center space-x-4 mt-4">
        <button 
          className="timer-button w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
          onClick={skipToNext}
          aria-label="Skip to next"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 16.811c0 .864-.933 1.406-1.683.977l-7.108-4.061a1.125 1.125 0 0 1 0-1.954l7.108-4.061A1.125 1.125 0 0 1 21 8.689v8.122ZM11.25 16.811c0 .864-.933 1.406-1.683.977l-7.108-4.061a1.125 1.125 0 0 1 0-1.954l7.108-4.061a1.125 1.125 0 0 1 1.683.977v8.122Z" />
          </svg>
        </button>
        
        {timerState === 'running' ? (
          <button 
            className="timer-button w-14 h-14 rounded-full bg-primary flex items-center justify-center text-white shadow-md transition-transform hover:scale-105 active:scale-95"
            onClick={pauseTimer}
            aria-label="Pause timer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
            </svg>
          </button>
        ) : (
          <button 
            className="timer-button w-14 h-14 rounded-full bg-primary flex items-center justify-center text-white shadow-md transition-transform hover:scale-105 active:scale-95"
            onClick={startTimer}
            aria-label="Start timer"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z" />
            </svg>
          </button>
        )}
        
        <button 
          className="timer-button w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
          onClick={resetTimer}
          aria-label="Reset timer"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default FocusTimer;
