import { useState, useEffect, useRef } from "react";
import { gsap } from "gsap";
import Header from "@/components/Header";
import ProgressRing from "@/components/ProgressRing";
import { useAppContext } from "@/context/AppContext";
import { formatDateShort } from "@/lib/dates";

// Import charts
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

const COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

const Progress = () => {
  const progressRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const weeklyRef = useRef<HTMLDivElement>(null);
  const categoryRef = useRef<HTMLDivElement>(null);
  const { tasks } = useAppContext();
  const [activeTab, setActiveTab] = useState<"week" | "month" | "year">("week");

  // Animation effects
  useEffect(() => {
    const timeline = gsap.timeline();
    
    timeline
      .from(progressRef.current, { opacity: 0, y: 20, duration: 0.5 })
      .from(statsRef.current, { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(weeklyRef.current, { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(categoryRef.current, { opacity: 0, y: 20, duration: 0.5 }, "-=0.3");
      
    return () => {
      timeline.kill();
    };
  }, []);

  // Calculate completion percentage
  const calculateCompletionRate = () => {
    if (tasks.length === 0) return 0;
    const completedTasks = tasks.filter(task => task.completed).length;
    return Math.round((completedTasks / tasks.length) * 100);
  };

  // Calculate study time (hours)
  const calculateStudyTime = () => {
    // This would normally come from actual time tracking data
    // For demo, we're generating some mock data based on task durations
    const totalMinutes = tasks.reduce((total, task) => {
      // Assuming duration is stored in minutes
      return total + (task.duration || 0);
    }, 0);
    
    return (totalMinutes / 60).toFixed(1);
  };

  // Get last 7 days data
  const getWeeklyData = () => {
    const weekData = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      
      // Count tasks for this day
      const dayTasks = tasks.filter(task => {
        const taskDate = new Date(task.date);
        return (
          taskDate.getDate() === date.getDate() &&
          taskDate.getMonth() === date.getMonth() &&
          taskDate.getFullYear() === date.getFullYear()
        );
      });
      
      const completed = dayTasks.filter(task => task.completed).length;
      
      weekData.push({
        name: date.toLocaleDateString('en-US', { weekday: 'short' }),
        total: dayTasks.length,
        completed: completed,
      });
    }
    
    return weekData;
  };

  // Get monthly data
  const getMonthlyData = () => {
    // For demo, we're using similar data as weekly but spread over a month
    // In a real app, this would be actual historical data
    return [
      { name: 'Week 1', total: 15, completed: 12 },
      { name: 'Week 2', total: 18, completed: 13 },
      { name: 'Week 3', total: 20, completed: 16 },
      { name: 'Week 4', total: 16, completed: 11 }
    ];
  };

  // Get yearly data
  const getYearlyData = () => {
    // For demo, using mocked data
    return [
      { name: 'Jan', total: 40, completed: 30 },
      { name: 'Feb', total: 45, completed: 38 },
      { name: 'Mar', total: 50, completed: 42 },
      { name: 'Apr', total: 55, completed: 45 },
      { name: 'May', total: 45, completed: 40 },
      { name: 'Jun', total: 50, completed: 45 },
      { name: 'Jul', total: 45, completed: 35 },
      { name: 'Aug', total: 40, completed: 30 },
      { name: 'Sep', total: 50, completed: 40 },
      { name: 'Oct', total: 60, completed: 50 },
      { name: 'Nov', total: 65, completed: 55 },
      { name: 'Dec', total: 50, completed: 45 }
    ];
  };

  // Get active data based on selected tab
  const getActiveData = () => {
    switch (activeTab) {
      case "week":
        return getWeeklyData();
      case "month":
        return getMonthlyData();
      case "year":
        return getYearlyData();
      default:
        return getWeeklyData();
    }
  };

  // Get category data
  const getCategoryData = () => {
    const categories: Record<string, number> = {};
    
    tasks.forEach(task => {
      if (task.category) {
        if (categories[task.category]) {
          categories[task.category]++;
        } else {
          categories[task.category] = 1;
        }
      }
    });
    
    return Object.keys(categories).map(key => ({
      name: key,
      value: categories[key]
    }));
  };

  // Get today's date
  const today = new Date();
  const formattedDate = formatDateShort(today);

  // Streak calculation (consecutive days with completed tasks)
  const calculateStreak = () => {
    let streak = 0;
    const today = new Date();
    
    // Check today first
    const todayTasks = tasks.filter(task => {
      const taskDate = new Date(task.date);
      return (
        taskDate.getDate() === today.getDate() &&
        taskDate.getMonth() === today.getMonth() &&
        taskDate.getFullYear() === today.getFullYear() &&
        task.completed
      );
    });
    
    if (todayTasks.length > 0) {
      streak = 1;
      
      // Check previous days
      for (let i = 1; i <= 30; i++) { // Check up to 30 days back
        const checkDate = new Date(today);
        checkDate.setDate(today.getDate() - i);
        
        const dayTasks = tasks.filter(task => {
          const taskDate = new Date(task.date);
          return (
            taskDate.getDate() === checkDate.getDate() &&
            taskDate.getMonth() === checkDate.getMonth() &&
            taskDate.getFullYear() === checkDate.getFullYear() &&
            task.completed
          );
        });
        
        if (dayTasks.length > 0) {
          streak++;
        } else {
          break;
        }
      }
    }
    
    return streak;
  };

  const activeData = getActiveData();
  const categoryData = getCategoryData();
  const completionRate = calculateCompletionRate();
  const studyTime = calculateStudyTime();
  const streak = calculateStreak();

  return (
    <div className="max-w-md mx-auto pb-20">
      <Header />
      
      <main className="px-4 pt-4 pb-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-heading font-semibold">Progress</h2>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            {formattedDate}
          </div>
        </div>
        
        {/* Overall Progress */}
        <section ref={progressRef} className="mb-8">
          <div className="bg-card rounded-xl shadow-md p-5">
            <h3 className="font-heading font-semibold text-lg mb-4">Overall Progress</h3>
            
            <div className="flex items-center justify-between">
              <ProgressRing 
                percentage={completionRate}
                size={100} 
                strokeWidth={8}
              />
              
              <div className="flex-1 pl-6 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Completion Rate</span>
                  <span className="text-xl font-bold text-primary">{completionRate}%</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Study Hours</span>
                  <span className="text-xl font-bold text-secondary">{studyTime}h</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Current Streak</span>
                  <span className="text-xl font-bold text-accent">{streak} days</span>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Weekly Stats */}
        <section ref={statsRef} className="mb-8">
          <div className="bg-card rounded-xl shadow-md p-5">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-heading font-semibold text-lg">Task Completion</h3>
              
              <div className="flex rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
                <button 
                  className={`px-3 py-1 text-sm ${activeTab === 'week' ? 'bg-primary text-white' : 'bg-transparent'}`}
                  onClick={() => setActiveTab('week')}
                >
                  Week
                </button>
                <button 
                  className={`px-3 py-1 text-sm ${activeTab === 'month' ? 'bg-primary text-white' : 'bg-transparent'}`}
                  onClick={() => setActiveTab('month')}
                >
                  Month
                </button>
                <button 
                  className={`px-3 py-1 text-sm ${activeTab === 'year' ? 'bg-primary text-white' : 'bg-transparent'}`}
                  onClick={() => setActiveTab('year')}
                >
                  Year
                </button>
              </div>
            </div>
            
            <div ref={weeklyRef} className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={activeData}
                  margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="total" name="Total Tasks" fill="hsl(var(--chart-2))" />
                  <Bar dataKey="completed" name="Completed" fill="hsl(var(--chart-1))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>
        
        {/* Task Categories */}
        <section ref={categoryRef}>
          <div className="bg-card rounded-xl shadow-md p-5">
            <h3 className="font-heading font-semibold text-lg mb-4">Task Categories</h3>
            
            {categoryData.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center">
                <div className="text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto mb-3 text-gray-300 dark:text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <p className="text-gray-500 dark:text-gray-400">
                    No task categories available
                  </p>
                  <p className="text-sm text-gray-400 dark:text-gray-500 mt-2">
                    Add tasks with categories to see the chart
                  </p>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

export default Progress;
