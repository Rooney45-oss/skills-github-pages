import { useState, useEffect } from "react";
import { gsap } from "gsap";
import Header from "@/components/Header";
import TaskCard from "@/components/TaskCard";
import NewTaskModal from "@/components/NewTaskModal";
import NotificationToast from "@/components/NotificationToast";
import { useAppContext } from "@/context/AppContext";
import { formatDateShort } from "@/lib/dates";

type CalendarDay = {
  date: Date;
  isCurrentMonth: boolean;
  isToday: boolean;
};

const Schedule = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarDays, setCalendarDays] = useState<CalendarDay[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [notification, setNotification] = useState({
    show: false,
    message: "",
    type: "success" as "success" | "error" | "warning"
  });
  const { tasks } = useAppContext();

  // Generate calendar days for current month view
  useEffect(() => {
    const days: CalendarDay[] = [];
    const today = new Date();
    
    // First day of the month
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    
    // Get the day of the week for the first day (0 = Sunday, 6 = Saturday)
    const firstDayOfWeek = firstDay.getDay();
    
    // Add days from previous month to fill the first week
    const prevMonthLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
    for (let i = firstDayOfWeek - 1; i >= 0; i--) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, prevMonthLastDay - i);
      days.push({
        date,
        isCurrentMonth: false,
        isToday: date.toDateString() === today.toDateString()
      });
    }
    
    // Add days of current month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
      days.push({
        date,
        isCurrentMonth: true,
        isToday: date.toDateString() === today.toDateString()
      });
    }
    
    // Add days from next month to fill remaining cells (to make it 42 total for 6 weeks)
    const remainingDays = 42 - days.length;
    for (let i = 1; i <= remainingDays; i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, i);
      days.push({
        date,
        isCurrentMonth: false,
        isToday: date.toDateString() === today.toDateString()
      });
    }
    
    setCalendarDays(days);
  }, [currentDate]);

  // Animation effects
  useEffect(() => {
    const timeline = gsap.timeline();
    
    timeline
      .from(".schedule-heading", { opacity: 0, y: -20, duration: 0.5 })
      .from(".calendar-controls", { opacity: 0, y: -20, duration: 0.5 }, "-=0.3")
      .from(".calendar-grid", { opacity: 0, y: 20, duration: 0.7 })
      .from(".task-list", { opacity: 0, y: 20, duration: 0.5 });
      
    return () => {
      timeline.kill();
    };
  }, []);

  // Navigate to previous month
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  // Navigate to next month
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  // Go to today
  const goToToday = () => {
    const today = new Date();
    setCurrentDate(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDate(today);
  };

  // Show notification toast
  const showNotification = (message: string, type: "success" | "error" | "warning" = "success") => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 3000);
  };

  // Get tasks for selected date
  const selectedDateTasks = tasks.filter(task => {
    const taskDate = new Date(task.date);
    return (
      taskDate.getDate() === selectedDate.getDate() &&
      taskDate.getMonth() === selectedDate.getMonth() &&
      taskDate.getFullYear() === selectedDate.getFullYear()
    );
  });

  // Format month name
  const monthName = currentDate.toLocaleString('default', { month: 'long' });
  const year = currentDate.getFullYear();

  // Days of week labels
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="max-w-md mx-auto pb-20">
      <Header />
      
      <main className="px-4 pt-4 pb-6">
        <div className="schedule-heading flex justify-between items-center mb-6">
          <h2 className="text-2xl font-heading font-semibold">Schedule</h2>
          <button 
            onClick={goToToday}
            className="px-3 py-1 bg-primary text-white rounded-md text-sm"
          >
            Today
          </button>
        </div>
        
        {/* Calendar Controls */}
        <div className="calendar-controls flex justify-between items-center mb-4">
          <button 
            onClick={prevMonth}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
            </svg>
          </button>
          
          <h3 className="text-lg font-medium">
            {monthName} {year}
          </h3>
          
          <button 
            onClick={nextMonth}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
            </svg>
          </button>
        </div>
        
        {/* Calendar Grid */}
        <div className="calendar-grid mb-6 bg-card rounded-xl shadow-md p-4">
          {/* Days of week header */}
          <div className="grid grid-cols-7 mb-2">
            {weekDays.map(day => (
              <div key={day} className="text-center text-sm text-gray-500 dark:text-gray-400">
                {day}
              </div>
            ))}
          </div>
          
          {/* Calendar days */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => {
              // Check if there are tasks for this day
              const dayTasks = tasks.filter(task => {
                const taskDate = new Date(task.date);
                return (
                  taskDate.getDate() === day.date.getDate() &&
                  taskDate.getMonth() === day.date.getMonth() &&
                  taskDate.getFullYear() === day.date.getFullYear()
                );
              });
              
              const hasTask = dayTasks.length > 0;
              
              // Check if this day is selected
              const isSelected = day.date.toDateString() === selectedDate.toDateString();
              
              return (
                <div 
                  key={index}
                  onClick={() => setSelectedDate(day.date)}
                  className={`
                    h-10 flex items-center justify-center rounded-full cursor-pointer 
                    transition-colors duration-200 relative
                    ${!day.isCurrentMonth ? 'text-gray-400 dark:text-gray-600' : ''}
                    ${day.isToday ? 'bg-primary text-white' : ''}
                    ${isSelected && !day.isToday ? 'bg-primary bg-opacity-10 text-primary' : ''}
                    ${!isSelected && !day.isToday ? 'hover:bg-gray-100 dark:hover:bg-gray-800' : ''}
                  `}
                >
                  <span>{day.date.getDate()}</span>
                  {hasTask && !day.isToday && (
                    <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full"></span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Selected Day Tasks */}
        <div className="task-list">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-heading font-semibold text-lg">
              {formatDateShort(selectedDate)}
            </h3>
            <button 
              onClick={() => setShowTaskModal(true)}
              className="text-primary font-medium flex items-center text-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              <span>Add Task</span>
            </button>
          </div>
          
          <div className="space-y-3">
            {selectedDateTasks.length > 0 ? (
              selectedDateTasks.map(task => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  onComplete={() => {
                    showNotification(`${task.title} marked as completed!`, "success");
                  }}
                  onDelete={() => {
                    showNotification(`${task.title} removed!`, "warning");
                  }}
                />
              ))
            ) : (
              <div className="bg-card rounded-lg p-8 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-gray-600">
                  <path fillRule="evenodd" d="M6.32 2.577a49.255 49.255 0 0 1 11.36 0c1.497.174 2.57 1.46 2.57 2.93V21a.75.75 0 0 1-1.085.67L12 18.089l-7.165 3.583A.75.75 0 0 1 3.75 21V5.507c0-1.47 1.073-2.756 2.57-2.93Z" clipRule="evenodd" />
                </svg>
                <p className="text-gray-500 dark:text-gray-400">No tasks for this day</p>
                <button 
                  onClick={() => setShowTaskModal(true)}
                  className="mt-4 px-4 py-2 bg-primary text-white rounded-md text-sm font-medium"
                >
                  Add a task
                </button>
              </div>
            )}
          </div>
        </div>
      </main>
      
      {/* Modals & Notifications */}
      <NewTaskModal 
        isOpen={showTaskModal} 
        onClose={() => setShowTaskModal(false)}
        initialDate={selectedDate}
        onTaskAdded={(task) => {
          showNotification(`Task "${task.title}" added successfully!`, "success");
        }}
      />
      
      <NotificationToast 
        show={notification.show}
        message={notification.message}
        type={notification.type}
        onClose={() => setNotification(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
};

export default Schedule;
