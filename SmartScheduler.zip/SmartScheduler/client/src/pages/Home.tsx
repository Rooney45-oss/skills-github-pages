import { useState, useEffect } from "react";
import { gsap } from "gsap";
import Header from "@/components/Header";
import ProgressRing from "@/components/ProgressRing";
import RevisionTimetable from "@/components/RevisionTimetable";
import FocusTimer from "@/components/FocusTimer";
import TaskCard from "@/components/TaskCard";
import AIAssistantModal from "@/components/AIAssistantModal";
import NewTaskModal from "@/components/NewTaskModal";
import NotificationToast from "@/components/NotificationToast";
import { formatDateLong } from "@/lib/dates";
import { useAppContext } from "@/context/AppContext";

const Home = () => {
  const [showAIModal, setShowAIModal] = useState(false);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [notification, setNotification] = useState<{show: boolean, message: string, type: 'success' | 'error' | 'warning'}>({
    show: false,
    message: "",
    type: "success"
  });
  const { tasks, userName } = useAppContext();

  useEffect(() => {
    // Initialize GSAP animations
    const timeline = gsap.timeline();
    
    timeline
      .from(".welcome-section", { opacity: 0, y: 20, duration: 0.5 })
      .from(".progress-section", { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(".ai-assistant-section", { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(".schedule-section", { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(".timetable-section", { opacity: 0, y: 20, duration: 0.5 }, "-=0.3")
      .from(".focus-timer-section", { opacity: 0, y: 20, duration: 0.5 }, "-=0.3");
      
    return () => {
      timeline.kill();
    };
  }, []);

  const showNotification = (message: string, type: 'success' | 'error' | 'warning' = 'success') => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 3000);
  };

  // Filter today's tasks
  const todayTasks = tasks.filter(task => {
    const taskDate = new Date(task.date);
    const today = new Date();
    return (
      taskDate.getDate() === today.getDate() &&
      taskDate.getMonth() === today.getMonth() &&
      taskDate.getFullYear() === today.getFullYear()
    );
  });

  // Calculate completion statistics
  const completedTasks = todayTasks.filter(task => task.completed).length;
  const totalTasks = todayTasks.length;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  // Calculate study time statistics (mocked for now)
  const studyTimeCompleted = 2; // hours
  const studyTimeTotal = 3; // hours
  const studyTimePercentage = Math.round((studyTimeCompleted / studyTimeTotal) * 100);
  
  // Calculate focus sessions statistics (mocked for now)
  const focusSessionsCompleted = 3;
  const focusSessionsTotal = 5;
  const focusSessionsPercentage = Math.round((focusSessionsCompleted / focusSessionsTotal) * 100);

  return (
    <div className="max-w-md mx-auto pb-20">
      <Header />
      
      <main className="px-4 pt-4 pb-6">
        {/* Welcome Section */}
        <section className="welcome-section mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-heading font-semibold">Hi, {userName || "User"}!</h2>
              <p className="text-gray-600 dark:text-gray-400">
                {formatDateLong(new Date())}
              </p>
            </div>
            <div className="relative">
              <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary to-accent text-white flex items-center justify-center shadow-md">
                <span className="font-semibold">{userName ? userName[0] : "U"}</span>
              </div>
              <div className="absolute -top-1 -right-1 h-3 w-3 bg-success rounded-full border-2 border-light-bg dark:border-dark-bg"></div>
            </div>
          </div>
        </section>
        
        {/* Progress Overview */}
        <section className="progress-section mb-8">
          <div className="bg-card rounded-xl shadow-md p-4">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-heading font-semibold text-lg">Today's Progress</h3>
              <button 
                className="text-sm text-primary font-medium"
                onClick={() => window.location.href = "/progress"}
              >
                View Details
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <ProgressRing 
                percentage={completionPercentage}
                size={100} 
                strokeWidth={8}
              />
              
              <div className="flex-1 pl-6">
                <div className="mb-3">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Tasks</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{completedTasks}/{totalTasks}</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-primary h-2.5 rounded-full" 
                      style={{ width: `${completionPercentage}%` }}
                    />
                  </div>
                </div>
                
                <div className="mb-3">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Study Time</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{studyTimeCompleted}h/{studyTimeTotal}h</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-secondary h-2.5 rounded-full" 
                      style={{ width: `${studyTimePercentage}%` }}
                    />
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Focus Sessions</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{focusSessionsCompleted}/{focusSessionsTotal}</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-accent h-2.5 rounded-full" 
                      style={{ width: `${focusSessionsPercentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* AI Assistant Button */}
        <section className="ai-assistant-section mb-6">
          <button 
            onClick={() => setShowAIModal(true)}
            className="w-full bg-gradient-to-r from-primary via-accent to-secondary text-white py-4 px-6 rounded-xl shadow-md flex items-center justify-between transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98]"
            style={{
              backgroundSize: '200% 200%',
              animation: 'gradientShift 5s ease infinite'
            }}
          >
            <div className="flex items-center">
              <div className="mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                  <path d="M18.75 3.94L6.31 9a.75.75 0 0 0 0 1.393l2.238.693.959 3.35a.75.75 0 0 0 1.237.205l1.47-1.606 3.215 2.066a.75.75 0 0 0 1.144-.486l2.699-10.115a.75.75 0 0 0-.929-.929Z" />
                </svg>
              </div>
              <div className="text-left">
                <h3 className="font-heading font-semibold">AI Assistant</h3>
                <p className="text-sm text-white text-opacity-90">Plan your day intelligently</p>
              </div>
            </div>
            <div className="float-animation">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                <path fillRule="evenodd" d="M12 1.5a.75.75 0 0 1 .75.75V4.5a.75.75 0 0 1-1.5 0V2.25A.75.75 0 0 1 12 1.5ZM5.636 4.136a.75.75 0 0 1 1.06 0l1.592 1.591a.75.75 0 0 1-1.061 1.06l-1.591-1.59a.75.75 0 0 1 0-1.061Zm12.728 0a.75.75 0 0 1 0 1.06l-1.591 1.592a.75.75 0 0 1-1.06-1.061l1.59-1.591a.75.75 0 0 1 1.061 0Zm-6.816 4.496a.75.75 0 0 1 .82.311l5.228 7.917a.75.75 0 0 1-.777 1.148l-2.097-.43 1.045 3.9a.75.75 0 0 1-1.45.388l-1.044-3.899-1.601 1.42a.75.75 0 0 1-1.247-.606l.569-9.47a.75.75 0 0 1 .554-.68ZM3 10.5a.75.75 0 0 1 .75-.75H6a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 10.5Zm14.25 0a.75.75 0 0 1 .75-.75h2.25a.75.75 0 0 1 0 1.5H18a.75.75 0 0 1-.75-.75Zm-8.962 3.712a.75.75 0 0 1 0 1.061l-1.591 1.591a.75.75 0 1 1-1.061-1.06l1.591-1.592a.75.75 0 0 1 1.06 0Z" clipRule="evenodd" />
              </svg>
            </div>
          </button>
        </section>
        
        {/* Today's Schedule */}
        <section className="schedule-section mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-heading font-semibold text-lg">Today's Schedule</h3>
            <button 
              className="text-primary font-medium flex items-center text-sm"
              onClick={() => window.location.href = "/schedule"}
            >
              <span>View Calendar</span>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4 ml-1">
                <path fillRule="evenodd" d="M7.21 14.77a.75.75 0 0 1 .02-1.06L11.168 10 7.23 6.29a.75.75 0 1 1 1.04-1.08l4.5 4.25a.75.75 0 0 1 0 1.08l-4.5 4.25a.75.75 0 0 1-1.06-.02Z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          
          <div className="space-y-3">
            {todayTasks.length > 0 ? (
              todayTasks.map((task, index) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  onComplete={() => {
                    // Task completion is handled in TaskCard component
                    showNotification(`${task.title} marked as completed!`, "success");
                  }}
                  onDelete={() => {
                    // Task deletion is handled in TaskCard component
                    showNotification(`${task.title} removed!`, "warning");
                  }}
                />
              ))
            ) : (
              <div className="bg-card rounded-lg p-8 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-gray-600">
                  <path fillRule="evenodd" d="M6.32 2.577a49.255 49.255 0 0 1 11.36 0c1.497.174 2.57 1.46 2.57 2.93V21a.75.75 0 0 1-1.085.67L12 18.089l-7.165 3.583A.75.75 0 0 1 3.75 21V5.507c0-1.47 1.073-2.756 2.57-2.93Z" clipRule="evenodd" />
                </svg>
                <p className="text-gray-500 dark:text-gray-400">No tasks for today</p>
                <button 
                  onClick={() => setShowTaskModal(true)}
                  className="mt-4 px-4 py-2 bg-primary text-white rounded-md text-sm font-medium"
                >
                  Add a task
                </button>
              </div>
            )}
          </div>
        </section>
        
        {/* Revision Timetable */}
        <section className="timetable-section mb-6">
          <RevisionTimetable />
        </section>
        
        {/* Focus Timer */}
        <section className="focus-timer-section">
          <FocusTimer />
        </section>
      </main>
      
      {/* Modals */}
      <AIAssistantModal 
        isOpen={showAIModal} 
        onClose={() => setShowAIModal(false)} 
      />
      
      <NewTaskModal 
        isOpen={showTaskModal} 
        onClose={() => setShowTaskModal(false)}
        onTaskAdded={(task) => {
          showNotification(`Task "${task.title}" added successfully!`, "success");
        }}
      />
      
      {/* Toast Notification */}
      <NotificationToast 
        show={notification.show}
        message={notification.message}
        type={notification.type}
        onClose={() => setNotification(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
};

export default Home;
