import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { gsap } from "gsap";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAppContext } from "@/context/AppContext";
import { useDarkMode } from "@/hooks/useDarkMode";
import NotificationToast from "@/components/NotificationToast";

const Settings = () => {
  const [, setLocation] = useLocation();
  const { userName, setUserName, clearAllTasks, exportData, importData } = useAppContext();
  const { isDarkMode, toggleDarkMode } = useDarkMode();
  const [name, setName] = useState(userName || "");
  const [pomodoroDuration, setPomodoroDuration] = useState("25");
  const [breakDuration, setBreakDuration] = useState("5");
  const [notification, setNotification] = useState({
    show: false,
    message: "",
    type: "success" as "success" | "error" | "warning"
  });
  
  useEffect(() => {
    const timeline = gsap.timeline();
    
    timeline
      .from(".settings-header", { opacity: 0, y: -20, duration: 0.4 })
      .from(".settings-section", { opacity: 0, y: 20, stagger: 0.1, duration: 0.5 });
      
    return () => {
      timeline.kill();
    };
  }, []);

  const handleSaveProfile = () => {
    setUserName(name);
    showNotification("Profile updated successfully!");
  };

  const handleClearAllTasks = () => {
    if (window.confirm("Are you sure you want to clear all tasks? This action cannot be undone.")) {
      clearAllTasks();
      showNotification("All tasks have been cleared", "warning");
    }
  };

  const handleExportData = () => {
    exportData();
    showNotification("Data exported successfully! Check your downloads folder.");
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const result = event.target?.result as string;
          importData(result);
          showNotification("Data imported successfully!");
        } catch (error) {
          showNotification("Failed to import data. Invalid format.", "error");
        }
      };
      reader.readAsText(file);
    }
  };

  const showNotification = (message: string, type: "success" | "error" | "warning" = "success") => {
    setNotification({ show: true, message, type });
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, 3000);
  };

  return (
    <div className="max-w-md mx-auto pb-6">
      <header className="settings-header sticky top-0 z-40 bg-light-bg dark:bg-dark-bg backdrop-blur-md bg-opacity-70 dark:bg-opacity-70 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center px-4 py-3">
          <button 
            onClick={() => setLocation("/")}
            className="mr-4 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
          </button>
          <h1 className="font-heading font-bold text-xl">Settings</h1>
        </div>
      </header>
      
      <main className="px-4 pt-4">
        {/* Profile Settings */}
        <section className="settings-section mb-6 bg-card rounded-xl shadow-md p-5">
          <h2 className="font-heading font-semibold text-lg mb-4">Profile</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-1">Name</label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter your name"
              />
            </div>
            
            <Button onClick={handleSaveProfile} className="w-full">
              Save Profile
            </Button>
          </div>
        </section>
        
        {/* Appearance Settings */}
        <section className="settings-section mb-6 bg-card rounded-xl shadow-md p-5">
          <h2 className="font-heading font-semibold text-lg mb-4">Appearance</h2>
          
          <div className="flex items-center justify-between">
            <span>Dark Mode</span>
            <Switch checked={isDarkMode} onCheckedChange={toggleDarkMode} />
          </div>
        </section>
        
        {/* Timer Settings */}
        <section className="settings-section mb-6 bg-card rounded-xl shadow-md p-5">
          <h2 className="font-heading font-semibold text-lg mb-4">Focus Timer</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="pomodoro" className="block text-sm font-medium mb-1">Pomodoro Duration (minutes)</label>
              <Select value={pomodoroDuration} onValueChange={setPomodoroDuration}>
                <SelectTrigger>
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="20">20 minutes</SelectItem>
                  <SelectItem value="25">25 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">60 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label htmlFor="break" className="block text-sm font-medium mb-1">Break Duration (minutes)</label>
              <Select value={breakDuration} onValueChange={setBreakDuration}>
                <SelectTrigger>
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 minutes</SelectItem>
                  <SelectItem value="10">10 minutes</SelectItem>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="20">20 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>
        
        {/* Data Management */}
        <section className="settings-section mb-6 bg-card rounded-xl shadow-md p-5">
          <h2 className="font-heading font-semibold text-lg mb-4">Data Management</h2>
          
          <div className="space-y-4">
            <Button onClick={handleExportData} variant="outline" className="w-full">
              Export Data
            </Button>
            
            <div>
              <label htmlFor="import-file" className="w-full">
                <div className="bg-primary text-white py-2 px-4 rounded-md text-center cursor-pointer">
                  Import Data
                </div>
                <input 
                  id="import-file"
                  type="file" 
                  accept=".json" 
                  className="hidden"
                  onChange={handleImportData}
                />
              </label>
            </div>
            
            <Separator />
            
            <Button onClick={handleClearAllTasks} variant="destructive" className="w-full">
              Clear All Tasks
            </Button>
          </div>
        </section>
        
        {/* App Info */}
        <section className="settings-section mb-6 bg-card rounded-xl shadow-md p-5">
          <h2 className="font-heading font-semibold text-lg mb-4">About</h2>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">Version</span>
              <span>1.0.0</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">Made with</span>
              <span>❤️</span>
            </div>
          </div>
        </section>
      </main>
      
      {/* Notification Toast */}
      <NotificationToast 
        show={notification.show}
        message={notification.message}
        type={notification.type}
        onClose={() => setNotification(prev => ({ ...prev, show: false }))}
      />
    </div>
  );
};

export default Settings;
