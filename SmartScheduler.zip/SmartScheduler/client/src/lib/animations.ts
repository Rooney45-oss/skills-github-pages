import { gsap } from "gsap";

// Reusable animation utilities for consistent animations across components

/**
 * Fade in element from opacity 0 to 1
 */
export const fadeIn = (
  element: HTMLElement | null,
  duration = 0.5,
  delay = 0,
  from = { opacity: 0, y: 20 }
) => {
  if (!element) return;
  
  return gsap.from(element, {
    opacity: from.opacity,
    y: from.y,
    duration,
    delay,
    ease: "power3.out"
  });
};

/**
 * Staggered fade in for multiple elements
 */
export const staggerFadeIn = (
  elements: NodeListOf<Element> | HTMLElement[] | null,
  duration = 0.5,
  staggerTime = 0.1,
  delay = 0,
  from = { opacity: 0, y: 20 }
) => {
  if (!elements) return;
  
  return gsap.from(elements, {
    opacity: from.opacity,
    y: from.y,
    duration,
    delay,
    stagger: staggerTime,
    ease: "power3.out"
  });
};

/**
 * Scale animation for elements
 */
export const scaleAnimation = (
  element: HTMLElement | null,
  duration = 0.5,
  from = { scale: 0.9 },
  to = { scale: 1 }
) => {
  if (!element) return;
  
  return gsap.fromTo(
    element,
    { scale: from.scale },
    { scale: to.scale, duration, ease: "back.out(1.7)" }
  );
};

/**
 * Slide in animation (different directions)
 */
export const slideIn = (
  element: HTMLElement | null,
  direction: 'left' | 'right' | 'up' | 'down' = 'up',
  duration = 0.5,
  delay = 0
) => {
  if (!element) return;
  
  const xValue = direction === 'left' ? -50 : direction === 'right' ? 50 : 0;
  const yValue = direction === 'up' ? -50 : direction === 'down' ? 50 : 0;
  
  return gsap.from(element, {
    x: xValue,
    y: yValue,
    opacity: 0,
    duration,
    delay,
    ease: "power3.out"
  });
};

/**
 * Float animation (continuous)
 */
export const floatAnimation = (element: HTMLElement | null, duration = 2, yValue = 10) => {
  if (!element) return;
  
  return gsap.to(element, {
    y: yValue,
    duration,
    repeat: -1,
    yoyo: true,
    ease: "sine.inOut"
  });
};

/**
 * Pulse animation (continuous)
 */
export const pulseAnimation = (element: HTMLElement | null, duration = 1.5, scale = 1.05) => {
  if (!element) return;
  
  return gsap.to(element, {
    scale,
    duration,
    repeat: -1,
    yoyo: true,
    ease: "sine.inOut"
  });
};

/**
 * Animate progress from 0 to target value
 */
export const animateCount = (
  element: HTMLElement | null,
  endValue: number,
  duration = 1.5,
  prefix = '',
  suffix = ''
) => {
  if (!element) return;
  
  let startValue = 0;
  
  return gsap.to(startValue, {
    duration,
    value: endValue,
    ease: "power2.out",
    onUpdate: function() {
      // @ts-ignore - value is dynamically added by GSAP
      const currentValue = Math.round(this.targets()[0]);
      if (element) {
        element.textContent = `${prefix}${currentValue}${suffix}`;
      }
    }
  });
};

/**
 * Animate element out before removing from DOM
 */
export const animateOut = (
  element: HTMLElement | null,
  onComplete?: () => void,
  duration = 0.3
) => {
  if (!element) {
    if (onComplete) onComplete();
    return;
  }
  
  return gsap.to(element, {
    opacity: 0,
    y: 20,
    duration,
    ease: "power3.in",
    onComplete: () => {
      if (onComplete) onComplete();
    }
  });
};
