// Types for AI chat functionality
export interface AIChatMessage {
  role: 'ai' | 'user';
  content: string;
}

interface UserContext {
  userName: string;
  taskCount: number;
  completedTaskCount: number;
}

// Smart response generation based on user input
export const generateResponse = async (
  userMessage: string, 
  messageHistory: AIChatMessage[],
  context: UserContext
): Promise<string> => {
  const lowercaseMessage = userMessage.toLowerCase();
  
  // Check if message contains keywords to determine intent
  if (containsRevisionKeywords(lowercaseMessage)) {
    return generateRevisionResponse(context);
  }
  
  if (containsScheduleKeywords(lowercaseMessage)) {
    return generateScheduleResponse(context);
  }
  
  if (containsProductivityKeywords(lowercaseMessage)) {
    return generateProductivityResponse(context);
  }
  
  if (containsGreeting(lowercaseMessage)) {
    return generateGreetingResponse(context);
  }
  
  // Default response if no specific intent is detected
  return `I can help you organize your day and create a revision timetable, ${context.userName}. Would you like me to:
  
1. Create a daily schedule for you
2. Generate a revision timetable for your subjects
3. Suggest productivity techniques
4. Set up focus sessions

Just let me know what you need help with!`;
};

// Check if message contains revision-related keywords
const containsRevisionKeywords = (message: string): boolean => {
  const revisionKeywords = [
    'revision', 'revise', 'study', 'exam', 'test', 'subject',
    'course', 'revision timetable', 'revision schedule'
  ];
  
  return revisionKeywords.some(keyword => message.includes(keyword));
};

// Check if message contains schedule-related keywords
const containsScheduleKeywords = (message: string): boolean => {
  const scheduleKeywords = [
    'schedule', 'plan', 'organize', 'organise', 'day', 'time',
    'timetable', 'calendar', 'agenda', 'routine'
  ];
  
  return scheduleKeywords.some(keyword => message.includes(keyword));
};

// Check if message contains productivity-related keywords
const containsProductivityKeywords = (message: string): boolean => {
  const productivityKeywords = [
    'productivity', 'focus', 'concentrate', 'efficient', 'distraction',
    'procrastination', 'technique', 'method', 'pomodoro'
  ];
  
  return productivityKeywords.some(keyword => message.includes(keyword));
};

// Check if message is a greeting
const containsGreeting = (message: string): boolean => {
  const greetings = [
    'hi', 'hello', 'hey', 'greetings', 'good morning', 'good afternoon',
    'good evening', 'howdy', 'sup', 'what\'s up', 'yo'
  ];
  
  return greetings.some(greeting => 
    message === greeting || message.startsWith(`${greeting} `)
  );
};

// Generate a response for revision-related queries
const generateRevisionResponse = (context: UserContext): string => {
  return `I can definitely help with your revision, ${context.userName}! Based on effective study techniques and your current task completion rate (${context.completedTaskCount}/${context.taskCount}), I recommend:

1. **Spaced Repetition**: Review material at increasing intervals
2. **Active Recall**: Test yourself rather than just re-reading notes
3. **Interleaving**: Mix subjects rather than blocking one subject at a time

Would you like me to create a detailed timetable based on these techniques? I can include breaks and focus sessions customized for your subjects.`;
};

// Generate a response for schedule-related queries
const generateScheduleResponse = (context: UserContext): string => {
  return `I'd be happy to help organize your day, ${context.userName}! An effective daily schedule should include:

1. **Morning Routine**: Start with a consistent wake-up time and planning session
2. **Focus Blocks**: 90-minute focused work sessions with breaks in between
3. **Buffer Time**: Allow flexibility between tasks for unexpected events
4. **Review Time**: End the day by reviewing progress and planning tomorrow

Would you like me to create a detailed timetable based on these principles? I can customize it based on your most important tasks.`;
};

// Generate a response for productivity-related queries
const generateProductivityResponse = (context: UserContext): string => {
  return `Great question about productivity, ${context.userName}! Here are some techniques that might help you:

1. **Pomodoro Technique**: Work for 25 minutes, then take a 5-minute break
2. **Time Blocking**: Schedule specific blocks of time for each task
3. **Task Batching**: Group similar tasks together
4. **2-Minute Rule**: If a task takes less than 2 minutes, do it immediately

The built-in Focus Timer in this app uses the Pomodoro technique. Would you like me to help you implement any of these methods into your schedule?`;
};

// Generate a greeting response
const generateGreetingResponse = (context: UserContext): string => {
  const currentHour = new Date().getHours();
  let timeOfDay = "day";
  
  if (currentHour < 12) {
    timeOfDay = "morning";
  } else if (currentHour < 18) {
    timeOfDay = "afternoon";
  } else {
    timeOfDay = "evening";
  }
  
  return `Good ${timeOfDay}, ${context.userName}! How can I assist you today? I can help with:

- Creating a study schedule
- Generating a revision timetable
- Suggesting productivity techniques
- Planning your day efficiently

What would you like to focus on?`;
};

// Generate a mock AI schedule
export const generateMockSchedule = (
  subjects?: string[],
  startDate?: Date
): any[] => {
  const defaultSubjects = [
    "Mathematics", 
    "Physics", 
    "Chemistry", 
    "Biology", 
    "History", 
    "English"
  ];
  
  const subjectsToUse = subjects || defaultSubjects;
  const startDateToUse = startDate || new Date();
  
  // Generate a schedule for 5 days starting from startDate
  const schedule = [];
  
  for (let i = 0; i < 5; i++) {
    const date = new Date(startDateToUse);
    date.setDate(startDateToUse.getDate() + i);
    
    // Generate 3-5 tasks for the day
    const taskCount = Math.floor(Math.random() * 3) + 3;
    const dailyTasks = [];
    
    for (let j = 0; j < taskCount; j++) {
      const subject = subjectsToUse[Math.floor(Math.random() * subjectsToUse.length)];
      
      // Generate start time between 8 AM and 5 PM
      const hour = Math.floor(Math.random() * 9) + 8;
      const minute = Math.floor(Math.random() * 4) * 15; // 0, 15, 30, or 45
      
      // Duration between 30 and 120 minutes
      const durationMinutes = (Math.floor(Math.random() * 4) + 1) * 30;
      
      // Calculate end time
      const endHour = hour + Math.floor((minute + durationMinutes) / 60);
      const endMinute = (minute + durationMinutes) % 60;
      
      // Format times
      const startTime = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      const endTime = `${endHour.toString().padStart(2, '0')}:${endMinute.toString().padStart(2, '0')}`;
      
      dailyTasks.push({
        id: `task-${Date.now()}-${j}`,
        title: `${subject} ${getRandomTask(subject)}`,
        date: date.toISOString().split('T')[0],
        startTime,
        endTime,
        category: getTaskCategory(subject),
        notes: "",
        completed: false,
        duration: durationMinutes
      });
    }
    
    // Sort tasks by start time
    dailyTasks.sort((a, b) => {
      return a.startTime.localeCompare(b.startTime);
    });
    
    schedule.push(...dailyTasks);
  }
  
  return schedule;
};

// Get a random task name based on subject
const getRandomTask = (subject: string): string => {
  const taskTypes = {
    "Mathematics": [
      "Problem Set", 
      "Revision", 
      "Calculus Practice", 
      "Algebra Review", 
      "Geometry Problems"
    ],
    "Physics": [
      "Lab Report", 
      "Problem Solving", 
      "Mechanics Review", 
      "Electricity Concepts", 
      "Waves Study"
    ],
    "Chemistry": [
      "Periodic Table Review", 
      "Molecular Structure", 
      "Reactions Practice", 
      "Lab Preparation", 
      "Organic Chemistry"
    ],
    "Biology": [
      "Cell Structure Review", 
      "Ecosystem Study", 
      "Evolution Concepts", 
      "Genetics Problems", 
      "Anatomy Notes"
    ],
    "History": [
      "Essay Outline", 
      "Source Analysis", 
      "Timeline Creation", 
      "Revolution Study", 
      "Historical Figure Research"
    ],
    "English": [
      "Literature Analysis", 
      "Essay Writing", 
      "Grammar Practice", 
      "Vocabulary Building", 
      "Reading Comprehension"
    ]
  };
  
  // Default task types for subjects not in the list
  const defaultTaskTypes = [
    "Review", 
    "Practice", 
    "Study Session", 
    "Notes Organization", 
    "Concept Mapping"
  ];
  
  const availableTasks = taskTypes[subject as keyof typeof taskTypes] || defaultTaskTypes;
  return availableTasks[Math.floor(Math.random() * availableTasks.length)];
};

// Get category based on subject
const getTaskCategory = (subject: string): string => {
  const categories: Record<string, string> = {
    "Mathematics": "Study",
    "Physics": "Study",
    "Chemistry": "Study",
    "Biology": "Study",
    "History": "Revision",
    "English": "Assignment"
  };
  
  return categories[subject] || "Study";
};
