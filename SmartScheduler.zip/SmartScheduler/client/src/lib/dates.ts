/**
 * Format date as "Thursday, 18 May"
 */
export const formatDateLong = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });
};

/**
 * Format date as "Thu, May 18"
 */
export const formatDateShort = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric'
  });
};

/**
 * Format time as "9:00 AM"
 */
export const formatTime = (timeString: string): string => {
  try {
    // Parse 24-hour time format (HH:MM)
    const [hours, minutes] = timeString.split(':').map(Number);
    
    // Create date object and set time
    const date = new Date();
    date.setHours(hours, minutes);
    
    // Format as 12-hour time with AM/PM
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  } catch (error) {
    console.error('Error formatting time:', error);
    return timeString;
  }
};

/**
 * Format date for input element (YYYY-MM-DD)
 */
export const formatDateForInput = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  
  return `${year}-${month}-${day}`;
};

/**
 * Get relative time description (today, tomorrow, yesterday, or formatted date)
 */
export const getRelativeTimeDescription = (dateString: string): string => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  if (isSameDay(date, today)) {
    return 'Today';
  } else if (isSameDay(date, tomorrow)) {
    return 'Tomorrow';
  } else if (isSameDay(date, yesterday)) {
    return 'Yesterday';
  } else {
    return formatDateShort(date);
  }
};

/**
 * Check if two dates are the same day
 */
const isSameDay = (date1: Date, date2: Date): boolean => {
  return (
    date1.getDate() === date2.getDate() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getFullYear() === date2.getFullYear()
  );
};

/**
 * Get the week number for a given date
 */
export const getWeekNumber = (date: Date): number => {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date.getTime() - firstDayOfYear.getTime()) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
};

/**
 * Get an array of dates for a given week
 */
export const getDatesInWeek = (date: Date): Date[] => {
  const day = date.getDay(); // 0 = Sunday, 6 = Saturday
  const result = [];
  
  // Get first day of week (Monday)
  const first = new Date(date);
  const dayOffset = day === 0 ? -6 : 1 - day; // Adjust for Sunday
  first.setDate(date.getDate() + dayOffset);
  
  // Add 7 days to array
  for (let i = 0; i < 7; i++) {
    const nextDate = new Date(first);
    nextDate.setDate(first.getDate() + i);
    result.push(nextDate);
  }
  
  return result;
};
